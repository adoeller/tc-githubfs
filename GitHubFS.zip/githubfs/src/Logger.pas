{$IFDEF FPC}{$MODE Delphi}{$ENDIF}
unit Logger;
(* Forwards errors to TC's log panel via the WFX LogProc callback.
   No file output, no OutputDebugString. *)

interface

uses
  Windows, SysUtils, fsplugin;

procedure LogInit(APluginNr: Integer; ALogProc: TLogProcW;
                  const ALogFilePath: string);
procedure LogMsg(const Msg: string);
procedure LogErr(const Msg: string);

implementation

var
  GPluginNr : Integer;
  GLogProc  : TLogProcW;

procedure LogInit(APluginNr: Integer; ALogProc: TLogProcW;
                  const ALogFilePath: string);
begin
  GPluginNr := APluginNr;
  GLogProc  := ALogProc;
  // ALogFilePath intentionally ignored - file logging removed
  if ALogFilePath = '' then ;
end;

procedure LogMsg(const Msg: string);
var
  W : WideString;
begin
  if Assigned(GLogProc) then
  begin
    W := WideString(Msg);
    GLogProc(GPluginNr, msgtype_details, PWideChar(W));
  end;
end;

procedure LogErr(const Msg: string);
var
  W : WideString;
begin
  if Assigned(GLogProc) then
  begin
    W := WideString(Msg);
    GLogProc(GPluginNr, msgtype_importanterror, PWideChar(W));
  end;
end;

initialization
  GPluginNr := 0;
  GLogProc  := nil;

end.
