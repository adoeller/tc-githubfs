{$IFDEF FPC}{$MODE Delphi}{$ENDIF}
(*
  ConfigDlg.pas  -  Win32 configuration dialog for GitHubFS WFX plugin

  DPI-aware layout: all coordinates are design pixels at 96 DPI, scaled
  at runtime via MulDiv(value, dpi, 96).
  Window size is calculated from the desired client area via AdjustWindowRectEx.
  The system message font is applied to every control.
  Edit fields show tooltip hints on hover.
*)
unit ConfigDlg;

interface

uses
  Windows, SysUtils, CommCtrl,
  GitHubTypes, PluginConfig, GitHubAPI, GitHubCache, Logger;

function ShowConfigDialog(AParent: HWND): Boolean;

function ShowQuickAddDialog(AParent: HWND;
                            out NewDisplayName: string): Boolean;

implementation

{$WARN 5057 OFF}  // local var not init (FillChar counts as init)
{$WARN 5058 OFF}  // managed type var
{$WARN 5083 OFF}  // pointer/ordinal conversion

// ---------------------------------------------------------------------------
//  Control IDs (private to implementation)
// ---------------------------------------------------------------------------
const
  ID_LV_REPOS       = 1001;
  ID_BTN_ADD        = 1002;
  ID_BTN_EDIT       = 1003;
  ID_BTN_DELETE     = 1004;
  ID_BTN_TEST       = 1005;
  ID_LBL_CFG        = 1006;
  ID_EDT_GLOBAL_TOK = 1007;
  ID_LBL_GLOBAL_TOK = 1008;

  ID_EDT_DISPLAY    = 2001;
  ID_EDT_OWNER      = 2002;
  ID_EDT_REPO       = 2003;
  ID_EDT_TOKEN      = 2004;
  ID_CHK_ENABLED    = 2005;
  ID_EDT_BRANCH     = 2006;

// ---------------------------------------------------------------------------
//  Dialog data records
// ---------------------------------------------------------------------------
type
  TMainDlgData = record
    Repos   : TRepoConfigArray;
    Changed : Boolean;
  end;
  PMainDlgData = ^TMainDlgData;

  TEditDlgData = record
    Repo  : TRepoConfig;
    IsNew : Boolean;
    OK    : Boolean;
  end;
  PEditDlgData = ^TEditDlgData;

  TGetDpiForWindowFn = function(hwnd: HWND): UINT; stdcall;

var
  GMainData         : PMainDlgData;
  GEditData         : PEditDlgData;
  GEditFont         : HFONT;
  GMainFont         : HFONT;
  GDpiFn            : TGetDpiForWindowFn;
  GDpiFnResolved    : Boolean;

// ===========================================================================
//  DPI / scaling
// ===========================================================================

function GetWindowDPI(hw: HWND): Integer;
var
  hU : HMODULE;
  dc : HDC;
begin
  if not GDpiFnResolved then
  begin
    GDpiFnResolved := True;
    hU := GetModuleHandleW('user32.dll');
    if hU <> 0 then
      @GDpiFn := GetProcAddress(hU, 'GetDpiForWindow');
  end;
  if Assigned(GDpiFn) then
  begin
    Result := Integer(GDpiFn(hw));
    Exit;
  end;
  dc := GetDC(0);
  Result := GetDeviceCaps(dc, LOGPIXELSX);
  ReleaseDC(0, dc);
end;

// Scale a design pixel (at 96 dpi) to actual DPI
function Sc(px, dpi: Integer): Integer;
begin
  Result := MulDiv(px, dpi, 96);
end;

// ===========================================================================
//  Font
// ===========================================================================

function CreateDialogFont: HFONT;
(*
  FPC's Windows unit does not expose TNonClientMetrics(W) in all versions.
  We declare a compatible struct inline so the code compiles everywhere.
  Only cbSize + lfMessageFont matter; the padding fields are zeroed.
*)
type
  TNCMetrics = packed record
    cbSize            : UINT;
    iBorderWidth      : Integer;
    iScrollWidth      : Integer;
    iScrollHeight     : Integer;
    iCaptionWidth     : Integer;
    iCaptionHeight    : Integer;
    lfCaptionFont     : LOGFONTW;
    iSmCaptionWidth   : Integer;
    iSmCaptionHeight  : Integer;
    lfSmCaptionFont   : LOGFONTW;
    iMenuWidth        : Integer;
    iMenuHeight       : Integer;
    lfMenuFont        : LOGFONTW;
    lfStatusFont      : LOGFONTW;
    lfMessageFont     : LOGFONTW;
    iPaddedBorderWidth: Integer;   // Windows Vista+; zero on XP, ignored
  end;
var
  ncm : TNCMetrics;
begin
  FillChar(ncm, SizeOf(ncm), 0);
  ncm.cbSize := SizeOf(ncm);
  if SystemParametersInfoW(SPI_GETNONCLIENTMETRICS, SizeOf(ncm), @ncm, 0) then
    Result := CreateFontIndirectW(ncm.lfMessageFont)
  else
    Result := HFONT(GetStockObject(DEFAULT_GUI_FONT));
end;

function ApplyFontEnum(hw: HWND; lp: LPARAM): BOOL; stdcall;
begin
  SendMessage(hw, WM_SETFONT, WPARAM(lp), 1);
  Result := True;
end;

procedure ApplyFontToAll(hWin: HWND; hFnt: HFONT);
begin
  SendMessage(hWin, WM_SETFONT, WPARAM(hFnt), 1);
  EnumChildWindows(hWin, @ApplyFontEnum, LPARAM(hFnt));
end;

// ===========================================================================
//  Window-size helper: desired client rect -> total window rect
// ===========================================================================

function WinSize(ClientW, ClientH: Integer; ExStyle, Style: DWORD): TSize;
var
  R : TRect;
begin
  R.Left := 0; R.Top := 0;
  R.Right := ClientW; R.Bottom := ClientH;
  AdjustWindowRectEx(R, Style, False, ExStyle);
  Result.cx := R.Right  - R.Left;
  Result.cy := R.Bottom - R.Top;
end;

// ===========================================================================
//  Tooltip helpers
// ===========================================================================

function CreateTT(hParent: HWND): HWND;
begin
  Result := CreateWindowExW(WS_EX_TOPMOST,
    TOOLTIPS_CLASS, nil,
    WS_POPUP or TTS_ALWAYSTIP or TTS_BALLOON or TTS_NOPREFIX,
    CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
    hParent, 0, HInstance, nil);
  if Result <> 0 then
  begin
    SetWindowPos(Result, HWND_TOPMOST, 0,0,0,0,
      SWP_NOMOVE or SWP_NOSIZE or SWP_NOACTIVATE);
    SendMessage(Result, TTM_SETDELAYTIME, TTDT_AUTOPOP, 8000);
    SendMessage(Result, TTM_SETDELAYTIME, TTDT_INITIAL,  500);
    SendMessage(Result, TTM_SETMAXTIPWIDTH, 0, 380);
  end;
end;

procedure AddTip(hTT, hCtrl: HWND; const Tip: WideString);
var
  ti : TToolInfoW;
begin
  if hTT = 0 then Exit;
  FillChar(ti, SizeOf(ti), 0);
  ti.cbSize   := SizeOf(ti);
  ti.uFlags   := TTF_IDISHWND or TTF_SUBCLASS;
  ti.hwnd     := GetParent(hCtrl);
  ti.uId      := UINT_PTR(hCtrl);
  ti.lpszText := PWideChar(Tip);
  SendMessage(hTT, TTM_ADDTOOLW, 0, LPARAM(PtrUInt(@ti)));
end;

// ===========================================================================
//  ListView helpers
// ===========================================================================

procedure SetCtrlText(hWin: HWND; ID: Integer; const S: WideString);
begin
  SetDlgItemTextW(hWin, ID, PWideChar(S));
end;

function GetCtrlText(hWin: HWND; ID: Integer): WideString;
var
  Buf : array[0..2047] of WideChar;
begin
  Buf[0] := WideChar(0);
  GetDlgItemTextW(hWin, ID, Buf, Length(Buf));
  Result := WideString(Buf);
end;

procedure LVAddCol(hLV: HWND; Idx: Integer; const Cap: WideString; W: Integer);
var
  Col : LVCOLUMNW;
begin
  FillChar(Col, SizeOf(Col), 0);
  Col.mask     := LVCF_TEXT or LVCF_WIDTH or LVCF_SUBITEM;
  Col.cx       := W;
  Col.iSubItem := Idx;
  Col.pszText  := PWideChar(Cap);
  SendMessage(hLV, LVM_INSERTCOLUMNW, WPARAM(Idx), LPARAM(PtrUInt(@Col)));
end;

procedure LVSetSubItem(hLV: HWND; Row, Col: Integer; const S: WideString);
var
  Item : LVITEMW;
begin
  FillChar(Item, SizeOf(Item), 0);
  Item.mask     := LVIF_TEXT;
  Item.iItem    := Row;
  Item.iSubItem := Col;
  Item.pszText  := PWideChar(S);
  if Col = 0 then
    SendMessage(hLV, LVM_INSERTITEMW, 0, LPARAM(PtrUInt(@Item)))
  else
    SendMessage(hLV, LVM_SETITEMW,    0, LPARAM(PtrUInt(@Item)));
end;

procedure LVPopulate(hLV: HWND; const Repos: TRepoConfigArray);
var
  I   : Integer;
  Ena : WideString;
begin
  SendMessage(hLV, LVM_DELETEALLITEMS, 0, 0);
  for I := 0 to High(Repos) do
  begin
    if Repos[I].Enabled then Ena := 'Yes' else Ena := 'No';
    LVSetSubItem(hLV, I, 0, WideString(Repos[I].DisplayName));
    LVSetSubItem(hLV, I, 1, WideString(Repos[I].Owner + '/' + Repos[I].RepoName));
    LVSetSubItem(hLV, I, 2, Ena);
  end;
end;

function LVGetSel(hLV: HWND): Integer;
begin
  Result := SendMessage(hLV, LVM_GETNEXTITEM, WPARAM(-1), LVNI_SELECTED);
end;

// ===========================================================================
//  Edit-repository dialog
//
//  Design layout at 96 DPI (scaled at runtime):
//
//   y=14   [Display Name:   ] [_________________________________]
//   y=48   [GitHub Owner:   ] [_________________________________]
//   y=82   [Repository:     ] [_________________________________]
//   y=116  [Access Token:   ] [*********************************]
//   y=152  [x] Enabled (visible in Total Commander)
//   y=190  _________________ [   OK   ] [  Cancel  ]
//
//  Client: 476 x 228
// ===========================================================================

function EditWndProc(hWin: HWND; uMsg: UINT;
                     aWParam: WPARAM; aLParam: LPARAM): LRESULT; stdcall;
var
  D                    : Integer;
  Pad, LblX, LblW, LblH: Integer;
  FldX, FldW, FldH     : Integer;
  LblOff, RowH         : Integer;
  BtnW, BtnH           : Integer;
  Y1, Y2, Y3, Y4, Y5   : Integer;
  ChkY, BtnY           : Integer;
  CW, CH               : Integer;
  WS                   : TSize;
  hTT                  : HWND;
  {%H-}R               : TRepoConfig;{%H+}
  NewToken             : string;
  Checked              : LRESULT;
begin
  Result := 0;
  case uMsg of

    WM_CREATE:
    begin
      D := GetWindowDPI(hWin);
      Pad    := Sc(10, D);
      LblX   := Pad;
      LblW   := Sc(116, D);
      LblH   := Sc(16,  D);
      FldX   := Sc(136, D);
      FldW   := Sc(326, D);
      FldH   := Sc(22,  D);
      LblOff := (FldH - LblH) div 2;
      RowH   := FldH + Sc(10, D);
      BtnW   := Sc(84, D);
      BtnH   := Sc(26, D);
      Y1     := Sc(12, D);
      Y2     := Y1 + RowH;
      Y3     := Y2 + RowH;
      Y4     := Y3 + RowH;
      Y5     := Y4 + RowH;          // new: Default Branch row
      ChkY   := Y5 + FldH + Sc(10, D);
      BtnY   := ChkY + Sc(20, D) + Sc(10, D);
      CW     := FldX + FldW + Pad;
      CH     := BtnY + BtnH + Pad;

      WS := WinSize(CW, CH,
        WS_EX_DLGMODALFRAME or WS_EX_TOPMOST,
        WS_OVERLAPPED or WS_CAPTION or WS_SYSMENU);
      SetWindowPos(hWin, 0, 0,0, WS.cx, WS.cy,
        SWP_NOMOVE or SWP_NOZORDER or SWP_NOACTIVATE);

      // Labels (vertically centred in field height)
      CreateWindowExW(0, 'STATIC', 'Display Name:',
        WS_CHILD or WS_VISIBLE or SS_LEFT,
        LblX, Y1 + LblOff, LblW, LblH,
        hWin, HMENU(PtrUInt(100)), HInstance, nil);
      CreateWindowExW(0, 'STATIC', 'GitHub Owner:',
        WS_CHILD or WS_VISIBLE or SS_LEFT,
        LblX, Y2 + LblOff, LblW, LblH,
        hWin, HMENU(PtrUInt(101)), HInstance, nil);
      CreateWindowExW(0, 'STATIC', 'Repository:',
        WS_CHILD or WS_VISIBLE or SS_LEFT,
        LblX, Y3 + LblOff, LblW, LblH,
        hWin, HMENU(PtrUInt(102)), HInstance, nil);
      CreateWindowExW(0, 'STATIC', 'Access Token:',
        WS_CHILD or WS_VISIBLE or SS_LEFT,
        LblX, Y4 + LblOff, LblW, LblH,
        hWin, HMENU(PtrUInt(103)), HInstance, nil);

      // Edit fields
      CreateWindowExW(WS_EX_CLIENTEDGE, 'EDIT', '',
        WS_CHILD or WS_VISIBLE or WS_TABSTOP or ES_AUTOHSCROLL,
        FldX, Y1, FldW, FldH,
        hWin, HMENU(PtrUInt(ID_EDT_DISPLAY)), HInstance, nil);
      CreateWindowExW(WS_EX_CLIENTEDGE, 'EDIT', '',
        WS_CHILD or WS_VISIBLE or WS_TABSTOP or ES_AUTOHSCROLL,
        FldX, Y2, FldW, FldH,
        hWin, HMENU(PtrUInt(ID_EDT_OWNER)), HInstance, nil);
      CreateWindowExW(WS_EX_CLIENTEDGE, 'EDIT', '',
        WS_CHILD or WS_VISIBLE or WS_TABSTOP or ES_AUTOHSCROLL,
        FldX, Y3, FldW, FldH,
        hWin, HMENU(PtrUInt(ID_EDT_REPO)), HInstance, nil);
      CreateWindowExW(WS_EX_CLIENTEDGE, 'EDIT', '',
        WS_CHILD or WS_VISIBLE or WS_TABSTOP or ES_AUTOHSCROLL or ES_PASSWORD,
        FldX, Y4, FldW, FldH,
        hWin, HMENU(PtrUInt(ID_EDT_TOKEN)), HInstance, nil);

      // Row 5: Default Branch (optional)
      CreateWindowExW(0, 'STATIC', 'Default Branch:',
        WS_CHILD or WS_VISIBLE or SS_LEFT,
        LblX, Y5 + LblOff, LblW, LblH,
        hWin, HMENU(PtrUInt(104)), HInstance, nil);
      CreateWindowExW(WS_EX_CLIENTEDGE, 'EDIT', '',
        WS_CHILD or WS_VISIBLE or WS_TABSTOP or ES_AUTOHSCROLL,
        FldX, Y5, FldW, FldH,
        hWin, HMENU(PtrUInt(ID_EDT_BRANCH)), HInstance, nil);

      // Cue banner (placeholder text, shown when field is empty)
      // EM_SETCUEBANNER = ECM_FIRST+1 = $1501; wParam=1 = show even when focused
      SendMessage(GetDlgItem(hWin, ID_EDT_DISPLAY), $1501, 1,
        LPARAM(PtrUInt(PWideChar(WideString('e.g. my-project')))));
      SendMessage(GetDlgItem(hWin, ID_EDT_OWNER),   $1501, 1,
        LPARAM(PtrUInt(PWideChar(WideString('e.g. octocat')))));
      SendMessage(GetDlgItem(hWin, ID_EDT_REPO),    $1501, 1,
        LPARAM(PtrUInt(PWideChar(WideString('e.g. Hello-World')))));
      SendMessage(GetDlgItem(hWin, ID_EDT_TOKEN),   $1501, 1,
        LPARAM(PtrUInt(PWideChar(WideString('ghp_xxxxxxxxxxxxxxxxxxxx')))));
      SendMessage(GetDlgItem(hWin, ID_EDT_BRANCH),  $1501, 1,
        LPARAM(PtrUInt(PWideChar(WideString('e.g. main  (leave empty to show all branches)')))));

      // Checkbox
      CreateWindowExW(0, 'BUTTON', 'Enabled (visible in Total Commander)',
        WS_CHILD or WS_VISIBLE or WS_TABSTOP or BS_AUTOCHECKBOX,
        LblX, ChkY, Sc(280, D), Sc(18, D),
        hWin, HMENU(PtrUInt(ID_CHK_ENABLED)), HInstance, nil);

      // Buttons (right-aligned)
      CreateWindowExW(0, 'BUTTON', 'OK',
        WS_CHILD or WS_VISIBLE or WS_TABSTOP or BS_DEFPUSHBUTTON,
        CW - 2*BtnW - Sc(8, D), BtnY, BtnW, BtnH,
        hWin, HMENU(PtrUInt(IDOK)), HInstance, nil);
      CreateWindowExW(0, 'BUTTON', 'Cancel',
        WS_CHILD or WS_VISIBLE or WS_TABSTOP or BS_PUSHBUTTON,
        CW - BtnW, BtnY, BtnW, BtnH,
        hWin, HMENU(PtrUInt(IDCANCEL)), HInstance, nil);

      // System font
      GEditFont := CreateDialogFont;
      if GEditFont <> 0 then ApplyFontToAll(hWin, GEditFont);

      // Tooltip hints
      hTT := CreateTT(hWin);
      AddTip(hTT, GetDlgItem(hWin, ID_EDT_DISPLAY),
        'A short label shown in Total Commander Network Neighborhood.' + #13#10 +
        'Example: my-project');
      AddTip(hTT, GetDlgItem(hWin, ID_EDT_OWNER),
        'GitHub username or organisation that owns the repository.' + #13#10 +
        'Example: octocat');
      AddTip(hTT, GetDlgItem(hWin, ID_EDT_REPO),
        'Repository name without the owner prefix.' + #13#10 +
        'Example: Hello-World');
      AddTip(hTT, GetDlgItem(hWin, ID_EDT_TOKEN),
        'Personal Access Token (PAT) with "Contents: Read" permission.' + #13#10 +
        'Create at: github.com/settings/tokens' + #13#10 +
        'Leave blank when editing to keep the existing token.' + #13#10 +
        'Stored encrypted with Windows DPAPI.');
      AddTip(hTT, GetDlgItem(hWin, ID_EDT_BRANCH),
        'Optional: enter a branch name to skip the branch list and' + #13#10 +
        'go directly to its root when opening this repository.' + #13#10 +
        'Leave blank to show all branches.');
      AddTip(hTT, GetDlgItem(hWin, ID_CHK_ENABLED),
        'Uncheck to hide this entry without deleting it.');

      // Populate existing values
      if GEditData <> nil then
      begin
        SetCtrlText(hWin, ID_EDT_DISPLAY, WideString(GEditData^.Repo.DisplayName));
        SetCtrlText(hWin, ID_EDT_OWNER,   WideString(GEditData^.Repo.Owner));
        SetCtrlText(hWin, ID_EDT_REPO,    WideString(GEditData^.Repo.RepoName));
        SetCtrlText(hWin, ID_EDT_BRANCH,  WideString(GEditData^.Repo.DefaultBranch));
        if GEditData^.Repo.Enabled then
          SendDlgItemMessage(hWin, ID_CHK_ENABLED, BM_SETCHECK, BST_CHECKED, 0);
      end;

      SetFocus(GetDlgItem(hWin, ID_EDT_DISPLAY));
    end;

    WM_COMMAND:
    case LOWORD(aWParam) of
      IDOK:
      begin
        if GEditData = nil then begin DestroyWindow(hWin); Exit; end;
        R.DisplayName    := string(GetCtrlText(hWin, ID_EDT_DISPLAY));
        R.Owner          := string(GetCtrlText(hWin, ID_EDT_OWNER));
        R.RepoName       := string(GetCtrlText(hWin, ID_EDT_REPO));
        R.DefaultBranch  := string(GetCtrlText(hWin, ID_EDT_BRANCH));
        R.EncryptedToken := '';
        Checked       := SendDlgItemMessage(hWin, ID_CHK_ENABLED, BM_GETCHECK, 0, 0);
        R.Enabled     := (Checked = BST_CHECKED);
        if (R.DisplayName = '') or (R.Owner = '') or (R.RepoName = '') then
        begin
          MessageBoxW(hWin,
            'Display Name, Owner and Repository must not be empty.',
            'Validation', MB_OK or MB_ICONWARNING);
          Exit;
        end;
        NewToken := string(GetCtrlText(hWin, ID_EDT_TOKEN));
        if NewToken <> '' then
          R.EncryptedToken := EncryptToken(NewToken)
        else
          R.EncryptedToken := GEditData^.Repo.EncryptedToken;
        GEditData^.Repo := R;
        GEditData^.OK   := True;
        DestroyWindow(hWin);
      end;
      IDCANCEL:
        DestroyWindow(hWin);
    end;

    WM_DESTROY:
    begin
      if GEditFont <> 0 then begin DeleteObject(GEditFont); GEditFont := 0; end;
      PostQuitMessage(0);
    end;

    WM_CLOSE: DestroyWindow(hWin);

  else
    Result := DefWindowProcW(hWin, uMsg, aWParam, aLParam);
  end;
end;

procedure RunEditWindow(AParent: HWND; var Data: TEditDlgData);
var
  {%H-}WC    : TWndClassExW;{%H+}
  hWin  : HWND;
  {%H-}Msg   : TMsg;{%H+}
  Cls   : WideString;
  Title : WideString;
begin
  GEditData := @Data;
  Cls       := 'GitHubFS_EditDlg';

  FillChar(WC, SizeOf(WC), 0);
  WC.cbSize        := SizeOf(WC);
  WC.style         := CS_HREDRAW or CS_VREDRAW;
  WC.lpfnWndProc   := @EditWndProc;
  WC.hInstance     := HInstance;
  WC.hbrBackground := HBRUSH(COLOR_BTNFACE + 1);
  WC.lpszClassName := PWideChar(Cls);
  WC.hCursor       := LoadCursor(0, IDC_ARROW);
  RegisterClassExW(WC);

  if Data.IsNew then Title := 'Add Repository'
  else               Title := 'Edit Repository';

  // Initial 200x100 will be corrected in WM_CREATE via AdjustWindowRectEx
  hWin := CreateWindowExW(
    WS_EX_DLGMODALFRAME or WS_EX_TOPMOST,
    PWideChar(Cls), PWideChar(Title),
    WS_OVERLAPPED or WS_CAPTION or WS_SYSMENU,
    CW_USEDEFAULT, CW_USEDEFAULT, 200, 100,
    AParent, 0, HInstance, nil);

  if hWin = 0 then
  begin
    GEditData := nil;
    UnregisterClassW(PWideChar(Cls), HInstance);
    Exit;
  end;

  ShowWindow(hWin, SW_SHOW);
  UpdateWindow(hWin);
  if AParent <> 0 then EnableWindow(AParent, False);

  while GetMessage(Msg, 0, 0, 0) do
  begin
    if not IsDialogMessage(hWin, Msg) then
    begin
      TranslateMessage(Msg);
      DispatchMessage(Msg);
    end;
  end;

  if AParent <> 0 then
  begin
    EnableWindow(AParent, True);
    SetForegroundWindow(AParent);
  end;
  UnregisterClassW(PWideChar(Cls), HInstance);
  GEditData := nil;
end;

// ===========================================================================
//  Main configuration dialog
//
//  Design layout at 96 DPI (scaled at runtime):
//
//   y=8    Config: C:\...\githubfs.ini
//   y=30   +-ListView (Display Name | Owner/Repo | Enabled)-+
//          |                                                 |
//          |  200px tall                                     |
//          +-------------------------------------------------+
//   y=238  [Add] [Edit] [Delete] [Test Connection]  [OK] [Cancel]
//
//  Client: 580 x 274
// ===========================================================================

function MainWndProc(hWin: HWND; uMsg: UINT;
                     aWParam: WPARAM; aLParam: LPARAM): LRESULT; stdcall;
var
  D               : Integer;
  Pad             : Integer;
  LvX, LvY, LvW, LvH : Integer;
  BtnY, BtnH      : Integer;
  SmW, TestW, LgW : Integer;
  CW, CH          : Integer;
  WS              : TSize;
  hLV             : HWND;
  hHdr            : HWND;
  SelIdx          : Integer;
  {%H-}Ed             : TEditDlgData;{%H+}
  Token           : string;
  TestMsg         : WideString;
  CfgLbl          : WideString;
  I, NewLen       : Integer;
begin
  Result := 0;
  case uMsg of

    WM_CREATE:
    begin
      D    := GetWindowDPI(hWin);
      Pad  := Sc(8, D);
      LvX  := Pad;
      LvY  := Sc(52, D);   // pushed down to make room for global token row
      LvW  := Sc(564, D);
      LvH  := Sc(400, D);
      BtnH := Sc(26, D);
      BtnY := LvY + LvH + Pad;
      SmW  := Sc(72, D);
      TestW:= Sc(120, D);
      LgW  := Sc(80, D);
      CW   := LvX + LvW + Pad;
      CH   := BtnY + BtnH + Pad;

      WS := WinSize(CW, CH,
        WS_EX_DLGMODALFRAME or WS_EX_TOPMOST,
        WS_OVERLAPPED or WS_CAPTION or WS_SYSMENU);
      SetWindowPos(hWin, 0, 0,0, WS.cx, WS.cy,
        SWP_NOMOVE or SWP_NOZORDER or SWP_NOACTIVATE);

      // Row 1: config path label
      CfgLbl := WideString('Config: ' + GetConfigPath);
      CreateWindowExW(0, 'STATIC', PWideChar(CfgLbl),
        WS_CHILD or WS_VISIBLE or SS_LEFT or SS_NOPREFIX,
        LvX, Pad, LvW, Sc(16, D),
        hWin, HMENU(PtrUInt(ID_LBL_CFG)), HInstance, nil);

      // Row 2: global token label + field
      CreateWindowExW(0, 'STATIC', 'Global Token:',
        WS_CHILD or WS_VISIBLE or SS_LEFT,
        LvX, Sc(26, D) + Sc(3, D), Sc(90, D), Sc(16, D),
        hWin, HMENU(PtrUInt(ID_LBL_GLOBAL_TOK)), HInstance, nil);
      CreateWindowExW(WS_EX_CLIENTEDGE, 'EDIT', '',
        WS_CHILD or WS_VISIBLE or WS_TABSTOP or ES_AUTOHSCROLL or ES_PASSWORD,
        LvX + Sc(96, D), Sc(24, D), LvW - Sc(96, D), Sc(20, D),
        hWin, HMENU(PtrUInt(ID_EDT_GLOBAL_TOK)), HInstance, nil);
      SendMessage(GetDlgItem(hWin, ID_EDT_GLOBAL_TOK), $1501, 1,
        LPARAM(PtrUInt(PWideChar(WideString(
          'Fallback token for repos without their own token')))));

      // Pre-fill global token field (show placeholder if set)
      SetCtrlText(hWin, ID_EDT_GLOBAL_TOK,
        WideString(LoadGlobalToken));

      // Repository list view
      hLV := CreateWindowExW(WS_EX_CLIENTEDGE, 'SysListView32', '',
        WS_CHILD or WS_VISIBLE or LVS_REPORT or LVS_SINGLESEL or LVS_SHOWSELALWAYS,
        LvX, LvY, LvW, LvH,
        hWin, HMENU(PtrUInt(ID_LV_REPOS)), HInstance, nil);
      SendMessage(hLV, LVM_SETEXTENDEDLISTVIEWSTYLE,
        LVS_EX_FULLROWSELECT, LVS_EX_FULLROWSELECT);

      // Color the column header: accent background + white text
      // HDM_SETBKCOLOR = $121D, HDM_SETTEXTCOLOR = $121E
      hHdr := SendMessage(hLV, LVM_GETHEADER, 0, 0);
      if hHdr <> 0 then
      begin
        SendMessage(hHdr, $121D, 0, LPARAM(GetSysColor(COLOR_ACTIVECAPTION)));
        SendMessage(hHdr, $121E, 0, LPARAM(GetSysColor(COLOR_CAPTIONTEXT)));
      end;

      LVAddCol(hLV, 0, 'Display Name', Sc(175, D));
      LVAddCol(hLV, 1, 'Owner / Repo', Sc(245, D));
      LVAddCol(hLV, 2, 'Enabled',      Sc(72,  D));
      if GMainData <> nil then
        LVPopulate(hLV, GMainData^.Repos);

      // Left buttons: Add / Edit / Delete / Test Connection
      CreateWindowExW(0, 'BUTTON', 'Add',
        WS_CHILD or WS_VISIBLE or WS_TABSTOP or BS_PUSHBUTTON,
        LvX, BtnY, SmW, BtnH,
        hWin, HMENU(PtrUInt(ID_BTN_ADD)), HInstance, nil);
      CreateWindowExW(0, 'BUTTON', 'Edit',
        WS_CHILD or WS_VISIBLE or WS_TABSTOP or BS_PUSHBUTTON,
        LvX + (SmW + Pad), BtnY, SmW, BtnH,
        hWin, HMENU(PtrUInt(ID_BTN_EDIT)), HInstance, nil);
      CreateWindowExW(0, 'BUTTON', 'Delete',
        WS_CHILD or WS_VISIBLE or WS_TABSTOP or BS_PUSHBUTTON,
        LvX + 2*(SmW + Pad), BtnY, SmW, BtnH,
        hWin, HMENU(PtrUInt(ID_BTN_DELETE)), HInstance, nil);
      CreateWindowExW(0, 'BUTTON', 'Test Connection',
        WS_CHILD or WS_VISIBLE or WS_TABSTOP or BS_PUSHBUTTON,
        LvX + 3*(SmW + Pad), BtnY, TestW, BtnH,
        hWin, HMENU(PtrUInt(ID_BTN_TEST)), HInstance, nil);

      // Right buttons: OK / Cancel
      CreateWindowExW(0, 'BUTTON', 'OK',
        WS_CHILD or WS_VISIBLE or WS_TABSTOP or BS_DEFPUSHBUTTON,
        CW - 2*(LgW + Pad), BtnY, LgW, BtnH,
        hWin, HMENU(PtrUInt(IDOK)), HInstance, nil);
      CreateWindowExW(0, 'BUTTON', 'Cancel',
        WS_CHILD or WS_VISIBLE or WS_TABSTOP or BS_PUSHBUTTON,
        CW - (LgW + Pad), BtnY, LgW, BtnH,
        hWin, HMENU(PtrUInt(IDCANCEL)), HInstance, nil);

      // System font
      GMainFont := CreateDialogFont;
      if GMainFont <> 0 then ApplyFontToAll(hWin, GMainFont);
    end;

    WM_COMMAND:
    case LOWORD(aWParam) of

      ID_BTN_ADD:
      begin
        if GMainData = nil then Exit;
        Ed.IsNew        := True;
        Ed.OK           := False;
        Ed.Repo.DisplayName    := '';
        Ed.Repo.Owner          := '';
        Ed.Repo.RepoName       := '';
        Ed.Repo.EncryptedToken := '';
        Ed.Repo.Enabled        := True;
        RunEditWindow(hWin, Ed);
        if Ed.OK then
        begin
          NewLen := Length(GMainData^.Repos) + 1;
          SetLength(GMainData^.Repos, NewLen);
          GMainData^.Repos[NewLen - 1] := Ed.Repo;
          GMainData^.Changed := True;
          LVPopulate(GetDlgItem(hWin, ID_LV_REPOS), GMainData^.Repos);
        end;
      end;

      ID_BTN_EDIT:
      begin
        if GMainData = nil then Exit;
        hLV    := GetDlgItem(hWin, ID_LV_REPOS);
        SelIdx := LVGetSel(hLV);
        if (SelIdx < 0) or (SelIdx > High(GMainData^.Repos)) then Exit;
        Ed.IsNew := False;
        Ed.OK    := False;
        Ed.Repo  := GMainData^.Repos[SelIdx];
        RunEditWindow(hWin, Ed);
        if Ed.OK then
        begin
          GMainData^.Repos[SelIdx] := Ed.Repo;
          GMainData^.Changed := True;
          LVPopulate(hLV, GMainData^.Repos);
        end;
      end;

      ID_BTN_DELETE:
      begin
        if GMainData = nil then Exit;
        hLV    := GetDlgItem(hWin, ID_LV_REPOS);
        SelIdx := LVGetSel(hLV);
        if (SelIdx < 0) or (SelIdx > High(GMainData^.Repos)) then Exit;
        if MessageBoxW(hWin, 'Delete the selected repository entry?',
             'Confirm Delete', MB_YESNO or MB_ICONQUESTION) <> IDYES then Exit;
        for I := SelIdx to High(GMainData^.Repos) - 1 do
          GMainData^.Repos[I] := GMainData^.Repos[I + 1];
        SetLength(GMainData^.Repos, Length(GMainData^.Repos) - 1);
        GMainData^.Changed := True;
        LVPopulate(hLV, GMainData^.Repos);
      end;

      ID_BTN_TEST:
      begin
        if GMainData = nil then Exit;
        hLV    := GetDlgItem(hWin, ID_LV_REPOS);
        SelIdx := LVGetSel(hLV);
        if (SelIdx < 0) or (SelIdx > High(GMainData^.Repos)) then
        begin
          MessageBoxW(hWin, 'Please select a repository first.',
            'Test Connection', MB_OK or MB_ICONINFORMATION);
          Exit;
        end;
        Token := GetEffectiveToken(GMainData^.Repos[SelIdx].EncryptedToken);
        if GHTestConnection(Token) then
          TestMsg := 'Connection successful!'
        else
          TestMsg := 'Connection failed.' + #13#10 +
                     'Check your access token and network connection.';
        MessageBoxW(hWin, PWideChar(TestMsg),
          'Test Connection', MB_OK or MB_ICONINFORMATION);
      end;

      IDOK:
      begin
        if GMainData <> nil then
        begin
          GMainData^.Changed := True;
          // Save global token (empty string clears it)
          SaveGlobalToken(string(GetCtrlText(hWin, ID_EDT_GLOBAL_TOK)));
        end;
        DestroyWindow(hWin);
      end;

      IDCANCEL:
      begin
        if GMainData <> nil then GMainData^.Changed := False;
        DestroyWindow(hWin);
      end;

    end;

    WM_DESTROY:
    begin
      if GMainFont <> 0 then begin DeleteObject(GMainFont); GMainFont := 0; end;
      PostQuitMessage(0);
    end;

    WM_CLOSE: DestroyWindow(hWin);

  else
    Result := DefWindowProcW(hWin, uMsg, aWParam, aLParam);
  end;
end;

// ===========================================================================
//  ShowConfigDialog  -  entry point called from FsExecuteFile
// ===========================================================================

function ShowConfigDialog(AParent: HWND): Boolean;
var
  Data : TMainDlgData;
  {%H-}WC   : TWndClassExW;{%H+}
  hWin : HWND;
  {%H-}Msg  : TMsg;{%H+}
  Cls  : WideString;
begin
  Result := False;
  Cls    := 'GitHubFS_MainDlg';

  Data.Repos   := LoadRepos;
  Data.Changed := False;
  GMainData    := @Data;

  FillChar(WC, SizeOf(WC), 0);
  WC.cbSize        := SizeOf(WC);
  WC.style         := CS_HREDRAW or CS_VREDRAW;
  WC.lpfnWndProc   := @MainWndProc;
  WC.hInstance     := HInstance;
  WC.hbrBackground := HBRUSH(COLOR_BTNFACE + 1);
  WC.lpszClassName := PWideChar(Cls);
  WC.hCursor       := LoadCursor(0, IDC_ARROW);
  RegisterClassExW(WC);

  // Initial size corrected in WM_CREATE
  hWin := CreateWindowExW(
    WS_EX_DLGMODALFRAME or WS_EX_TOPMOST,
    PWideChar(Cls), 'GitHub Filesystem - Configuration',
    WS_OVERLAPPED or WS_CAPTION or WS_SYSMENU,
    CW_USEDEFAULT, CW_USEDEFAULT, 200, 100,
    AParent, 0, HInstance, nil);

  if hWin = 0 then
  begin
    GMainData := nil;
    UnregisterClassW(PWideChar(Cls), HInstance);
    Exit;
  end;

  ShowWindow(hWin, SW_SHOW);
  UpdateWindow(hWin);
  if AParent <> 0 then EnableWindow(AParent, False);

  while GetMessage(Msg, 0, 0, 0) do
  begin
    if not IsDialogMessage(hWin, Msg) then
    begin
      TranslateMessage(Msg);
      DispatchMessage(Msg);
    end;
  end;

  if AParent <> 0 then
  begin
    EnableWindow(AParent, True);
    SetForegroundWindow(AParent);
  end;
  UnregisterClassW(PWideChar(Cls), HInstance);

  if Data.Changed then
  begin
    SaveRepos(Data.Repos);
    CacheClearAll;   // repo list may have changed - discard stale cache
    Result := True;
  end;
  GMainData := nil;
end;

// ===========================================================================
//  ShowQuickAddDialog  -  called from FsExecuteFile for [Quick add]
// ===========================================================================

function ShowQuickAddDialog(AParent: HWND;
                            out NewDisplayName: string): Boolean;
var
  Ed    : TEditDlgData;
  Repos : TRepoConfigArray;
  NewLen: Integer;
begin
  Result         := False;
  NewDisplayName := '';
  FillChar(Ed, SizeOf(Ed), 0);
  Ed.IsNew        := True;
  Ed.Repo.Enabled := True;
  RunEditWindow(AParent, Ed);
  if not Ed.OK then Exit;
  // Save to config immediately
  Repos  := LoadRepos;
  NewLen := Length(Repos) + 1;
  SetLength(Repos, NewLen);
  Repos[NewLen - 1] := Ed.Repo;
  SaveRepos(Repos);
  CacheClearAll;
  NewDisplayName := Ed.Repo.DisplayName;
  Result := True;
end;

initialization
  GMainData      := nil;
  GEditData      := nil;
  GEditFont      := 0;
  GMainFont      := 0;
  GDpiFn         := nil;
  GDpiFnResolved := False;

end.
