{$IFDEF FPC}{$MODE Delphi}{$ENDIF}
(*
  GitHubCache.pas  -  in-memory cache for GitHub API responses

  Assumption: repo contents do not change during a TC session.
  Caching eliminates repeated API calls when TC re-reads a directory
  (e.g. after F2 refresh, panel switch, or column-info requests).

  Cache keys:
    Branch list  : 'owner|repo'
    Contents list: 'owner|repo|branch|path'

  Invalidation:
    ClearAll    - called when configuration is saved (repos may have changed)
    ClearRepo   - called per-repo if needed in future
*)
unit GitHubCache;

interface

uses
  Windows, SysUtils, GitHubTypes;

{ Store / retrieve branch list for a repository.
  Get returns False on cache miss. }
function  CacheGetBranches(const Owner, Repo: string;
                           out Branches: TBranchArray): Boolean;
procedure CachePutBranches(const Owner, Repo: string;
                           const Branches: TBranchArray);

{ Store / retrieve directory contents.
  Path is the sub-path within the repo (empty = root). }
function  CacheGetContents(const Owner, Repo, Branch, Path: string;
                           out Contents: TContentArray): Boolean;
procedure CachePutContents(const Owner, Repo, Branch, Path: string;
                           const Contents: TContentArray);

{ Discard all cached data (call when config changes). }
procedure CacheClearAll;

{ Discard cached data for one repo only. }
procedure CacheClearRepo(const Owner, Repo: string);

{ Current cache statistics for diagnostics. }
procedure CacheStats(out BranchEntries, ContentEntries: Integer);

implementation

// ---------------------------------------------------------------------------
//  Internal types
// ---------------------------------------------------------------------------
type
  TBranchCacheEntry = record
    Key      : string;        // 'owner|repo'
    Branches : TBranchArray;
  end;

  TContentCacheEntry = record
    Key      : string;        // 'owner|repo|branch|path'
    Contents : TContentArray;
  end;

// ---------------------------------------------------------------------------
//  Module state
// ---------------------------------------------------------------------------
var
  GBranchCache  : array of TBranchCacheEntry;
  GContentCache : array of TContentCacheEntry;
  GCS           : TRTLCriticalSection;
  GCSInited     : Boolean;

// ---------------------------------------------------------------------------
//  Key builders
// ---------------------------------------------------------------------------
function BranchKey(const Owner, Repo: string): string;
begin
  Result := LowerCase(Owner) + '|' + LowerCase(Repo);
end;

function ContentKey(const Owner, Repo, Branch, Path: string): string;
begin
  Result := LowerCase(Owner) + '|' +
            LowerCase(Repo)  + '|' +
            LowerCase(Branch)+ '|' +
            LowerCase(Path);
end;

// ---------------------------------------------------------------------------
//  Branch cache
// ---------------------------------------------------------------------------
function CacheGetBranches(const Owner, Repo: string;
                          out Branches: TBranchArray): Boolean;
var
  K : string;
  I : Integer;
begin
  Result   := False;
  Branches := nil;
  if not GCSInited then Exit;
  K := BranchKey(Owner, Repo);
  EnterCriticalSection(GCS);
  try
    for I := 0 to High(GBranchCache) do
      if GBranchCache[I].Key = K then
      begin
        Branches := GBranchCache[I].Branches;
        Result   := True;
        Exit;
      end;
  finally
    LeaveCriticalSection(GCS);
  end;
end;

procedure CachePutBranches(const Owner, Repo: string;
                           const Branches: TBranchArray);
var
  K : string;
  I : Integer;
  N : Integer;
begin
  if not GCSInited then Exit;
  K := BranchKey(Owner, Repo);
  EnterCriticalSection(GCS);
  try
    // Update existing entry
    for I := 0 to High(GBranchCache) do
      if GBranchCache[I].Key = K then
      begin
        GBranchCache[I].Branches := Branches;
        Exit;
      end;
    // Append new entry
    N := Length(GBranchCache);
    SetLength(GBranchCache, N + 1);
    GBranchCache[N].Key      := K;
    GBranchCache[N].Branches := Branches;
  finally
    LeaveCriticalSection(GCS);
  end;
end;

// ---------------------------------------------------------------------------
//  Content cache
// ---------------------------------------------------------------------------
function CacheGetContents(const Owner, Repo, Branch, Path: string;
                          out Contents: TContentArray): Boolean;
var
  K : string;
  I : Integer;
begin
  Result   := False;
  Contents := nil;
  if not GCSInited then Exit;
  K := ContentKey(Owner, Repo, Branch, Path);
  EnterCriticalSection(GCS);
  try
    for I := 0 to High(GContentCache) do
      if GContentCache[I].Key = K then
      begin
        Contents := GContentCache[I].Contents;
        Result   := True;
        Exit;
      end;
  finally
    LeaveCriticalSection(GCS);
  end;
end;

procedure CachePutContents(const Owner, Repo, Branch, Path: string;
                           const Contents: TContentArray);
var
  K : string;
  I : Integer;
  N : Integer;
begin
  if not GCSInited then Exit;
  K := ContentKey(Owner, Repo, Branch, Path);
  EnterCriticalSection(GCS);
  try
    for I := 0 to High(GContentCache) do
      if GContentCache[I].Key = K then
      begin
        GContentCache[I].Contents := Contents;
        Exit;
      end;
    N := Length(GContentCache);
    SetLength(GContentCache, N + 1);
    GContentCache[N].Key      := K;
    GContentCache[N].Contents := Contents;
  finally
    LeaveCriticalSection(GCS);
  end;
end;

// ---------------------------------------------------------------------------
//  Invalidation
// ---------------------------------------------------------------------------
procedure CacheClearAll;
begin
  if not GCSInited then Exit;
  EnterCriticalSection(GCS);
  try
    SetLength(GBranchCache,  0);
    SetLength(GContentCache, 0);
  finally
    LeaveCriticalSection(GCS);
  end;
end;

procedure CacheClearRepo(const Owner, Repo: string);
var
  BK  : string;
  I, J: Integer;
begin
  if not GCSInited then Exit;
  BK := BranchKey(Owner, Repo);
  EnterCriticalSection(GCS);
  try
    // Remove matching branch entries
    I := 0;
    while I <= High(GBranchCache) do
    begin
      if GBranchCache[I].Key = BK then
      begin
        for J := I to High(GBranchCache) - 1 do
          GBranchCache[J] := GBranchCache[J + 1];
        SetLength(GBranchCache, Length(GBranchCache) - 1);
      end
      else
        Inc(I);
    end;
    // Remove matching content entries (prefix match on 'owner|repo|')
    I := 0;
    while I <= High(GContentCache) do
    begin
      if Copy(GContentCache[I].Key, 1, Length(BK) + 1) = BK + '|' then
      begin
        for J := I to High(GContentCache) - 1 do
          GContentCache[J] := GContentCache[J + 1];
        SetLength(GContentCache, Length(GContentCache) - 1);
      end
      else
        Inc(I);
    end;
  finally
    LeaveCriticalSection(GCS);
  end;
end;

procedure CacheStats(out BranchEntries, ContentEntries: Integer);
begin
  if not GCSInited then
  begin
    BranchEntries  := 0;
    ContentEntries := 0;
    Exit;
  end;
  EnterCriticalSection(GCS);
  try
    BranchEntries  := Length(GBranchCache);
    ContentEntries := Length(GContentCache);
  finally
    LeaveCriticalSection(GCS);
  end;
end;

// ---------------------------------------------------------------------------
initialization
  GCSInited := False;
  InitializeCriticalSection(GCS);
  GCSInited := True;

finalization
  if GCSInited then
  begin
    DeleteCriticalSection(GCS);
    GCSInited := False;
  end;

end.
