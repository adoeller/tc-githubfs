{$IFDEF FPC}{$MODE Delphi}{$ENDIF}
(*
  GitHubAPI.pas  -  GitHub REST API v3 client with full phase logging

  Every meaningful step writes a timestamped line to the log file so that
  connection failures can be diagnosed without a debugger.

  Log phases for a typical GHGetBranches call:
    [API] GHGetBranches -> /repos/owner/repo/branches?per_page=100
    [NET] EnsureWinInet: loading wininet.dll
    [NET] EnsureWinInet: wininet.dll loaded OK
    [NET] EnsureWinInet: InternetOpen OK (session created)
    [NET] HttpGet: InternetConnect -> api.github.com:443
    [NET] HttpGet: HttpOpenRequest GET /repos/...
    [NET] HttpGet: HttpSendRequest OK
    [NET] HttpGet: HTTP status 200
    [NET] HttpGet: body 1842 bytes received
    [API] GHGetBranches: parsed 3 branches

  GitHub error responses (non-200) log the server message field, e.g.:
    [API] GHGetBranches: HTTP 401 - "Bad credentials" (https://docs.github.com/...)
    [API] GHGetBranches: HTTP 404 - "Not Found"
    [API] GHGetBranches: HTTP 403 - "API rate limit exceeded for ..."
*)
unit GitHubAPI;

interface

uses
  Windows, SysUtils, Classes, GitHubTypes, Logger, fsplugin;

function GHTestConnection(const Token: string): Boolean;

function GHGetBranches(const Owner, Repo, Token: string;
  out Branches: TBranchArray): Boolean;

function GHGetContents(const Owner, Repo, Branch, TreePath, Token: string;
  out Entries: TContentArray): Boolean;

function GHDownloadFile(const Owner, Repo, Branch, FilePath, Token: string;
  const LocalPath: WideString;
  PluginNr: Integer; ProgressCb: TProgressProc;
  RemoteNameA, LocalNameA: PAnsiChar): Boolean;

implementation

uses
  fpjson, jsonparser, base64;

// ===========================================================================
//  WinInet dynamic binding
// ===========================================================================
const
  WININET_LIB                  = 'wininet.dll';
  INTERNET_OPEN_TYPE_PRECONFIG = 0;
  INTERNET_SERVICE_HTTP        = 3;
  INTERNET_FLAG_SECURE         = $00800000;
  INTERNET_FLAG_RELOAD         = $80000000;
  INTERNET_FLAG_NO_CACHE_WRITE = $04000000;
  HTTP_QUERY_STATUS_CODE       = 19;
  HTTP_QUERY_FLAG_NUMBER       = $20000000;
  INTERNET_DEFAULT_HTTPS_PORT  = 443;
  GITHUB_HOST                  = 'api.github.com';
  PLUGIN_USERAGENT             = 'TCGitHubFS/1.0 (+https://github.com)';

type
  HINTERNET = Pointer;

var
  GWinInetLib    : HMODULE;
  GWinInetReady  : Boolean;
  GInetSession   : HINTERNET;

  FnInternetOpenA     : function(lpszAgent: PAnsiChar; dwAccessType: DWORD;
                          lpszProxy, lpszProxyBypass: PAnsiChar;
                          dwFlags: DWORD): HINTERNET; stdcall;
  FnInternetConnectA  : function(hInternet: HINTERNET;
                          lpszServerName: PAnsiChar; nServerPort: WORD;
                          lpszUser, lpszPwd: PAnsiChar;
                          dwService, dwFlags: DWORD;
                          dwContext: DWORD_PTR): HINTERNET; stdcall;
  FnHttpOpenRequestA  : function(hConnect: HINTERNET;
                          lpszVerb, lpszObject, lpszVersion,
                          lpszReferrer: PAnsiChar;
                          lplpszAcceptTypes: Pointer;
                          dwFlags, dwContext: DWORD): HINTERNET; stdcall;
  FnHttpSendRequestA  : function(hRequest: HINTERNET;
                          lpszHeaders: PAnsiChar; dwHeadersLen: DWORD;
                          lpOptional: Pointer; dwOptionalLen: DWORD): BOOL; stdcall;
  FnInternetReadFile  : function(hFile: HINTERNET; lpBuffer: Pointer;
                          dwBytesToRead: DWORD;
                          var lpdwBytesRead: DWORD): BOOL; stdcall;
  FnInternetCloseHandle: function(hInternet: HINTERNET): BOOL; stdcall;
  FnHttpQueryInfoA    : function(hRequest: HINTERNET; dwInfoLevel: DWORD;
                          lpvBuffer: Pointer; var lpdwBufLen: DWORD;
                          lpdwIndex: PDWORD): BOOL; stdcall;

// ===========================================================================
//  WinInet loading
// ===========================================================================
procedure EnsureWinInet;
begin
  if GWinInetReady then Exit;
  LogMsg('[NET] EnsureWinInet: loading ' + WININET_LIB);
  GWinInetLib := LoadLibraryA(WININET_LIB);
  if GWinInetLib = 0 then
  begin
    LogErr('[NET] EnsureWinInet: LoadLibrary FAILED, GetLastError=' +
      IntToStr(GetLastError));
    Exit;
  end;
  LogMsg('[NET] EnsureWinInet: ' + WININET_LIB + ' loaded OK');

  @FnInternetOpenA      := GetProcAddress(GWinInetLib, 'InternetOpenA');
  @FnInternetConnectA   := GetProcAddress(GWinInetLib, 'InternetConnectA');
  @FnHttpOpenRequestA   := GetProcAddress(GWinInetLib, 'HttpOpenRequestA');
  @FnHttpSendRequestA   := GetProcAddress(GWinInetLib, 'HttpSendRequestA');
  @FnInternetReadFile   := GetProcAddress(GWinInetLib, 'InternetReadFile');
  @FnInternetCloseHandle:= GetProcAddress(GWinInetLib, 'InternetCloseHandle');
  @FnHttpQueryInfoA     := GetProcAddress(GWinInetLib, 'HttpQueryInfoA');

  // Log which procs are missing (unlikely but helpful)
  if not Assigned(FnInternetOpenA)      then LogErr('[NET] EnsureWinInet: InternetOpenA not found');
  if not Assigned(FnInternetConnectA)   then LogErr('[NET] EnsureWinInet: InternetConnectA not found');
  if not Assigned(FnHttpOpenRequestA)   then LogErr('[NET] EnsureWinInet: HttpOpenRequestA not found');
  if not Assigned(FnHttpSendRequestA)   then LogErr('[NET] EnsureWinInet: HttpSendRequestA not found');
  if not Assigned(FnInternetReadFile)   then LogErr('[NET] EnsureWinInet: InternetReadFile not found');
  if not Assigned(FnInternetCloseHandle)then LogErr('[NET] EnsureWinInet: InternetCloseHandle not found');
  if not Assigned(FnHttpQueryInfoA)     then LogMsg ('[NET] EnsureWinInet: HttpQueryInfoA not found (non-fatal)');

  if not (Assigned(FnInternetOpenA) and Assigned(FnInternetConnectA) and
          Assigned(FnHttpOpenRequestA) and Assigned(FnHttpSendRequestA) and
          Assigned(FnInternetReadFile) and Assigned(FnInternetCloseHandle)) then
  begin
    LogErr('[NET] EnsureWinInet: critical procs missing - aborting');
    FreeLibrary(GWinInetLib);
    GWinInetLib := 0;
    Exit;
  end;

  LogMsg('[NET] EnsureWinInet: InternetOpen (agent=' + PLUGIN_USERAGENT + ')');
  GInetSession := FnInternetOpenA(PLUGIN_USERAGENT,
    INTERNET_OPEN_TYPE_PRECONFIG, nil, nil, 0);
  if GInetSession = nil then
  begin
    LogErr('[NET] EnsureWinInet: InternetOpen FAILED, GetLastError=' +
      IntToStr(GetLastError));
    Exit;
  end;

  LogMsg('[NET] EnsureWinInet: session created OK');
  GWinInetReady := True;
end;

// ===========================================================================
//  URL encoding
// ===========================================================================
function UrlEncodePath(const S: string): string;
var
  I : Integer;
  B : Byte;
begin
  Result := '';
  for I := 1 to Length(S) do
  begin
    B := Byte(S[I]);
    if ((B >= Ord('A')) and (B <= Ord('Z'))) or
       ((B >= Ord('a')) and (B <= Ord('z'))) or
       ((B >= Ord('0')) and (B <= Ord('9'))) or
       (B = Ord('-')) or (B = Ord('_')) or
       (B = Ord('.')) or (B = Ord('~')) or
       (B = Ord('/')) then
      Result := Result + Char(B)
    else
      Result := Result + '%' + IntToHex(B, 2);
  end;
end;

// ===========================================================================
//  JSON helpers
// ===========================================================================
function ParseJSON(const S: string): TJSONData;
begin
  Result := nil;
  if S = '' then Exit;
  try
    Result := GetJSON(S);
  except
    on E: Exception do
      LogErr('[JSON] ParseJSON exception: ' + E.Message);
  end;
end;

function JObjStr(JObj: TJSONObject; const Key: string): string;
var
  D : TJSONData;
begin
  Result := '';
  D := JObj.Find(Key);
  if D <> nil then
    try Result := D.AsString; except end;
end;

function JObjInt(JObj: TJSONObject; const Key: string): Int64;
var
  D : TJSONData;
begin
  Result := 0;
  D := JObj.Find(Key);
  if D <> nil then
    try Result := D.AsInt64; except end;
end;

// Extract GitHub error message from a non-200 JSON response body.
// GitHub always returns {"message":"...","documentation_url":"..."}
function GitHubErrMsg(const Body: string): string;
var
  JD  : TJSONData;
  JO  : TJSONObject;
  Msg : string;
  Doc : string;
begin
  Result := Body;    // fallback: raw body (truncated)
  if Length(Result) > 300 then SetLength(Result, 300);
  if Body = '' then Exit;
  JD := nil;
  try
    JD := GetJSON(Body);
    if (JD <> nil) and (JD is TJSONObject) then
    begin
      JO  := TJSONObject(JD);
      Msg := JObjStr(JO, 'message');
      Doc := JObjStr(JO, 'documentation_url');
      if Msg <> '' then
      begin
        Result := '"' + Msg + '"';
        if Doc <> '' then Result := Result + '  (' + Doc + ')';
      end;
    end;
  except
  end;
  if JD <> nil then JD.Free;
end;

// Mask token for logging: show first 4 chars + asterisks
function MaskToken(const Token: string): string;
begin
  if Length(Token) <= 4 then
    Result := StringOfChar('*', Length(Token))
  else
    Result := Copy(Token, 1, 4) + StringOfChar('*', Length(Token) - 4);
end;

// ===========================================================================
//  Core HTTP GET
// ===========================================================================
function HttpGet(const APIPath, Token: string;
  out StatusCode: Integer): string;
var
  hConnect  : HINTERNET;
  hRequest  : HINTERNET;
  Headers   : AnsiString;
  MS        : TMemoryStream;
  Buf       : array[0..32767] of Byte;
  BytesRead : DWORD;
  StatusBuf : DWORD;
  BufLen    : DWORD;
  {%H-}RawResp   : AnsiString;{%H+}
  Snippet   : string;
begin
  Result     := '';
  StatusCode := 0;
  EnsureWinInet;
  if not GWinInetReady then
  begin
    LogErr('[NET] HttpGet: WinInet not ready - aborting');
    Exit;
  end;

  // Phase 1: connect to API host
  LogMsg('[NET] HttpGet: InternetConnect -> ' + GITHUB_HOST +
    ':' + IntToStr(INTERNET_DEFAULT_HTTPS_PORT));
  hConnect := FnInternetConnectA(GInetSession, GITHUB_HOST,
    INTERNET_DEFAULT_HTTPS_PORT, nil, nil,
    INTERNET_SERVICE_HTTP, 0, 0);
  if hConnect = nil then
  begin
    LogErr('[NET] HttpGet: InternetConnect FAILED, GetLastError=' +
      IntToStr(GetLastError));
    Exit;
  end;

  try
    // Phase 2: open request
    LogMsg('[NET] HttpGet: HttpOpenRequest GET ' + APIPath);
    hRequest := FnHttpOpenRequestA(hConnect, 'GET',
      PAnsiChar(AnsiString(APIPath)), 'HTTP/1.1', nil, nil,
      INTERNET_FLAG_SECURE or INTERNET_FLAG_RELOAD or
      INTERNET_FLAG_NO_CACHE_WRITE, 0);
    if hRequest = nil then
    begin
      LogErr('[NET] HttpGet: HttpOpenRequest FAILED, GetLastError=' +
        IntToStr(GetLastError));
      Exit;
    end;

    try
      // Phase 3: send request with auth header
      Headers := 'User-Agent: ' + PLUGIN_USERAGENT + #13#10 +
                 'Accept: application/vnd.github+json' + #13#10 +
                 'X-GitHub-Api-Version: 2022-11-28' + #13#10;
      if Token <> '' then
      begin
        Headers := Headers + 'Authorization: Bearer ' +
          AnsiString(Token) + #13#10;
        LogMsg('[NET] HttpGet: sending request (token=' + MaskToken(Token) + ')');
      end
      else
        LogMsg('[NET] HttpGet: sending request (no token - public repo)');

      if not FnHttpSendRequestA(hRequest,
        PAnsiChar(Headers), Length(Headers), nil, 0) then
      begin
        LogErr('[NET] HttpGet: HttpSendRequest FAILED, GetLastError=' +
          IntToStr(GetLastError) +
          ' (check firewall, proxy, TLS 1.2 support)');
        Exit;
      end;

      // Phase 4: read HTTP status code
      StatusBuf := 0;
      BufLen    := SizeOf(StatusBuf);
      if Assigned(FnHttpQueryInfoA) then
        FnHttpQueryInfoA(hRequest,
          HTTP_QUERY_STATUS_CODE or HTTP_QUERY_FLAG_NUMBER,
          @StatusBuf, BufLen, nil)
      else
        LogMsg('[NET] HttpGet: HttpQueryInfo not available - status unknown');
      StatusCode := Integer(StatusBuf);
      LogMsg('[NET] HttpGet: HTTP status ' + IntToStr(StatusCode) +
        ' for ' + APIPath);

      // Phase 5: read response body
      MS := TMemoryStream.Create;
      try
        repeat
          BytesRead := 0;
          if not FnInternetReadFile(hRequest, @Buf[0], SizeOf(Buf), BytesRead) then
          begin
            LogErr('[NET] HttpGet: InternetReadFile FAILED, GetLastError=' +
              IntToStr(GetLastError));
            Break;
          end;
          if BytesRead > 0 then
            MS.Write(Buf[0], BytesRead);
        until BytesRead = 0;

        LogMsg('[NET] HttpGet: body received, size=' + IntToStr(MS.Size) +
          ' bytes');

        if MS.Size > 0 then
        begin
          SetLength(RawResp, MS.Size);
          MS.Position := 0;
          MS.Read(RawResp[1], MS.Size);
          Result := string(RawResp);

          // Log first 200 chars of body as diagnostic snippet
          Snippet := Result;
          if Length(Snippet) > 200 then
          begin
            SetLength(Snippet, 200);
            Snippet := Snippet + '...';
          end;
          LogMsg('[NET] HttpGet: body snippet: ' + Snippet);
        end
        else
          LogMsg('[NET] HttpGet: body is empty');

      finally
        MS.Free;
      end;

    finally
      FnInternetCloseHandle(hRequest);
    end;
  finally
    FnInternetCloseHandle(hConnect);
  end;
end;

// ===========================================================================
//  Raw download to file (files > 1 MB via DownloadURL)
// ===========================================================================
function HttpDownloadToFile(const RawURL: string; const Token: string;
  const LocalPath: WideString;
  PluginNr: Integer; ProgressCb: TProgressProc;
  RemoteNameA, LocalNameA: PAnsiChar): Boolean;
var
  URL        : string;
  HostPart   : AnsiString;
  PathPart   : AnsiString;
  SlashPos   : Integer;
  hConnect   : HINTERNET;
  hRequest   : HINTERNET;
  Headers    : AnsiString;
  hFile      : THandle;
  Buf        : array[0..65535] of Byte;
  BytesRead  : DWORD;
  Written    : DWORD;
  StatusBuf  : DWORD;
  BufLen     : DWORD;
  StatusCode : Integer;
  TotalBytes : Int64;
  ContentLen : Int64;
  Pct        : Integer;
  PrevPct    : Integer;
  {%H-}CLBuf      : array[0..31] of AnsiChar;{%H+}
  CLLen      : DWORD;
begin
  Result := False;
  EnsureWinInet;
  if not GWinInetReady then Exit;

  URL := RawURL;
  if Copy(URL, 1, 8) = 'https://' then Delete(URL, 1, 8)
  else if Copy(URL, 1, 7) = 'http://' then Delete(URL, 1, 7);

  SlashPos := Pos('/', URL);
  if SlashPos > 0 then
  begin
    HostPart := AnsiString(Copy(URL, 1, SlashPos - 1));
    PathPart := AnsiString(Copy(URL, SlashPos, Length(URL)));
  end else
  begin
    HostPart := AnsiString(URL);
    PathPart := '/';
  end;

  LogMsg('[NET] HttpDownloadToFile: host=' + string(HostPart) +
    ' path=' + string(PathPart));

  hConnect := FnInternetConnectA(GInetSession, PAnsiChar(HostPart),
    INTERNET_DEFAULT_HTTPS_PORT, nil, nil,
    INTERNET_SERVICE_HTTP, 0, 0);
  if hConnect = nil then
  begin
    LogErr('[NET] HttpDownloadToFile: InternetConnect FAILED');
    Exit;
  end;
  try
    hRequest := FnHttpOpenRequestA(hConnect, 'GET', PAnsiChar(PathPart),
      'HTTP/1.1', nil, nil,
      INTERNET_FLAG_SECURE or INTERNET_FLAG_RELOAD or
      INTERNET_FLAG_NO_CACHE_WRITE, 0);
    if hRequest = nil then
    begin
      LogErr('[NET] HttpDownloadToFile: HttpOpenRequest FAILED');
      Exit;
    end;
    try
      Headers := 'User-Agent: ' + PLUGIN_USERAGENT + #13#10;
      if Token <> '' then
        Headers := Headers + 'Authorization: Bearer ' + AnsiString(Token) + #13#10;

      if not FnHttpSendRequestA(hRequest,
        PAnsiChar(Headers), Length(Headers), nil, 0) then
      begin
        LogErr('[NET] HttpDownloadToFile: HttpSendRequest FAILED, GetLastError=' +
          IntToStr(GetLastError));
        Exit;
      end;

      StatusBuf := 0;
      BufLen    := SizeOf(StatusBuf);
      if Assigned(FnHttpQueryInfoA) then
        FnHttpQueryInfoA(hRequest,
          HTTP_QUERY_STATUS_CODE or HTTP_QUERY_FLAG_NUMBER,
          @StatusBuf, BufLen, nil);
      StatusCode := Integer(StatusBuf);
      LogMsg('[NET] HttpDownloadToFile: HTTP status ' + IntToStr(StatusCode));
      if StatusCode <> 200 then Exit;

      // Try to get Content-Length for accurate progress
      ContentLen := 0;
      if Assigned(FnHttpQueryInfoA) then
      begin
        FillChar(CLBuf, SizeOf(CLBuf), 0);
        CLLen := SizeOf(CLBuf) - 1;
        if FnHttpQueryInfoA(hRequest, 5 {HTTP_QUERY_CONTENT_LENGTH},
                            @CLBuf, CLLen, nil) then
          ContentLen := StrToInt64Def(string(AnsiString(CLBuf)), 0);
      end;
      if ContentLen > 0 then
        LogMsg('[NET] HttpDownloadToFile: Content-Length=' + IntToStr(ContentLen));

      hFile := CreateFileW(PWideChar(LocalPath), GENERIC_WRITE, 0, nil,
        CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
      if hFile = INVALID_HANDLE_VALUE then
      begin
        LogErr('[NET] HttpDownloadToFile: cannot create local file, err=' +
          IntToStr(GetLastError));
        Exit;
      end;
      try
        TotalBytes := 0;
        PrevPct    := 0;
        repeat
          BytesRead := 0;
          Written   := 0;
          if not FnInternetReadFile(hRequest, @Buf[0], SizeOf(Buf), BytesRead) then
            Break;
          if BytesRead > 0 then
          begin
            WriteFile(hFile, Buf[0], BytesRead, Written, nil);
            Inc(TotalBytes, BytesRead);

            // Update progress at most once per percentage point
            if Assigned(ProgressCb) and (ContentLen > 0) then
            begin
              Pct := Integer(TotalBytes * 99 div ContentLen);
              if Pct > PrevPct then
              begin
                // ProgressCb returns non-zero if user clicked Abort
                if ProgressCb(PluginNr, RemoteNameA, LocalNameA, Pct) <> 0 then
                begin
                  LogMsg('[NET] HttpDownloadToFile: user aborted');
                  Break;
                end;
                PrevPct := Pct;
              end;
            end;
          end;
        until BytesRead = 0;
        LogMsg('[NET] HttpDownloadToFile: written ' + IntToStr(TotalBytes) + ' bytes');
        Result := True;
      finally
        CloseHandle(hFile);
        if not Result then DeleteFileW(PWideChar(LocalPath));
      end;
    finally
      FnInternetCloseHandle(hRequest);
    end;
  finally
    FnInternetCloseHandle(hConnect);
  end;
end;

// ===========================================================================
//  Public API implementations
// ===========================================================================

function GHTestConnection(const Token: string): Boolean;
var
  Status : Integer;
  Body   : string;
  Endpoint: string;
begin
  if Token <> '' then
  begin
    // With token: verify token validity via /user
    Endpoint := '/user';
    LogMsg('[API] GHTestConnection -> GET /user (token=' + MaskToken(Token) + ')');
    Body   := HttpGet(Endpoint, Token, Status);
    Result := (Status = 200);
    if Result then
      LogMsg('[API] GHTestConnection: OK - token valid, authenticated as user')
    else
    begin
      LogErr('[API] GHTestConnection: FAILED HTTP ' + IntToStr(Status) +
        ' - ' + GitHubErrMsg(Body));
      if Status = 401 then
        LogErr('[API] -> 401: token is invalid or expired')
      else if Status = 403 then
        LogErr('[API] -> 403: token lacks required scope (needs repo or public_repo)');
    end;
  end
  else
  begin
    // Without token: just verify network/DNS via /zen (always 200, no auth needed)
    Endpoint := '/zen';
    LogMsg('[API] GHTestConnection -> GET /zen (no token - testing network only)');
    Body   := HttpGet(Endpoint, '', Status);
    Result := (Status = 200);
    if Result then
      LogMsg('[API] GHTestConnection: OK - network reachable (no token provided; ' +
        'public repos accessible)')
    else
    begin
      LogErr('[API] GHTestConnection: FAILED HTTP ' + IntToStr(Status));
      if Status = 0 then
        LogErr('[API] -> status=0: cannot reach api.github.com ' +
          '(check network, DNS, firewall, proxy)');
    end;
  end;
end;

// ---------------------------------------------------------------------------

function GHGetBranches(const Owner, Repo, Token: string;
  out Branches: TBranchArray): Boolean;
var
  Path   : string;
  Body   : string;
  Status : Integer;
  JData  : TJSONData;
  JArr   : TJSONArray;
  JItem  : TJSONObject;
  JCmt   : TJSONData;
  I      : Integer;
begin
  Result   := False;
  Branches := nil;

  if Owner = '' then begin LogErr('[API] GHGetBranches: Owner is empty'); Exit; end;
  if Repo  = '' then begin LogErr('[API] GHGetBranches: Repo is empty');  Exit; end;

  Path := '/repos/' + UrlEncodePath(Owner) + '/' +
    UrlEncodePath(Repo) + '/branches?per_page=100';

  Body := HttpGet(Path, Token, Status);

  if Status <> 200 then
  begin
    LogErr('[API] GHGetBranches: HTTP ' + IntToStr(Status) +
      ' - ' + GitHubErrMsg(Body));
    if Status = 404 then
      MessageBoxW(0,
        PWideChar(WideString(
          'Repository not found: ' + Owner + '/' + Repo + #13#10 +
          #13#10 +
          'Possible causes:' + #13#10 +
          '  - Owner or repository name is misspelled' + #13#10 +
          '  - Repository is private and the token lacks read access' + #13#10 +
          '  - The token has expired or is invalid')),
        'GitHub FS - 404 Not Found',
        MB_OK or MB_ICONWARNING);
    Exit;
  end;

  LogMsg('[API] GHGetBranches: parsing JSON response');
  JData := ParseJSON(Body);
  if JData = nil then
  begin
    LogErr('[API] GHGetBranches: JSON parse failed - body was: ' +
      Copy(Body, 1, 200));
    Exit;
  end;
  try
    if not (JData is TJSONArray) then
    begin
      LogErr('[API] GHGetBranches: expected JSON array, got ' +
        JData.ClassName + ' - body: ' + Copy(Body, 1, 200));
      Exit;
    end;
    JArr := TJSONArray(JData);
    LogMsg('[API] GHGetBranches: ' + IntToStr(JArr.Count) + ' branches found');
    if JArr.Count = 0 then
      LogMsg('[API] GHGetBranches: repository has no branches (empty repo?)');

    SetLength(Branches, JArr.Count);
    for I := 0 to JArr.Count - 1 do
    begin
      if not (JArr[I] is TJSONObject) then Continue;
      JItem := TJSONObject(JArr[I]);
      Branches[I].Name := JObjStr(JItem, 'name');
      JCmt := JItem.Find('commit');
      if (JCmt <> nil) and (JCmt is TJSONObject) then
        Branches[I].CommitSHA := JObjStr(TJSONObject(JCmt), 'sha');
      LogMsg('[API]   branch[' + IntToStr(I) + ']: ' + Branches[I].Name +
        ' @ ' + Copy(Branches[I].CommitSHA, 1, 8));
    end;
    Result := True;
  finally
    JData.Free;
  end;
end;

// ---------------------------------------------------------------------------

function GHGetContents(const Owner, Repo, Branch, TreePath, Token: string;
  out Entries: TContentArray): Boolean;
var
  Path   : string;
  Body   : string;
  Status : Integer;
  JData  : TJSONData;
  JArr   : TJSONArray;
  JItem  : TJSONObject;
  I      : Integer;
  TP     : string;
  Loc    : string;
begin
  Result  := False;
  Entries := nil;

  TP := TreePath;
  while (TP <> '') and (TP[1] = '/') do Delete(TP, 1, 1);
  while (TP <> '') and (TP[1] = '\') do Delete(TP, 1, 1);

  Path := '/repos/' + UrlEncodePath(Owner) + '/' +
    UrlEncodePath(Repo) + '/contents';
  if TP <> '' then
    Path := Path + '/' + UrlEncodePath(TP);
  Path := Path + '?ref=' + UrlEncodePath(Branch);

  Body := HttpGet(Path, Token, Status);

  if Status <> 200 then
  begin
    LogErr('[API] GHGetContents: HTTP ' + IntToStr(Status) +
      ' - ' + GitHubErrMsg(Body));
    if Status = 404 then
    begin
      Loc := Owner + '/' + Repo;
      if Branch <> '' then Loc := Loc + '  branch: ' + Branch;
      if TP     <> '' then Loc := Loc + '  path: '   + TP;
      MessageBoxW(0,
        PWideChar(WideString(
          'Not found: ' + Loc + #13#10 +
          #13#10 +
          GitHubErrMsg(Body))),
        'GitHub FS - 404 Not Found',
        MB_OK or MB_ICONWARNING);
    end;
    Exit;
  end;

  LogMsg('[API] GHGetContents: parsing JSON response');
  JData := ParseJSON(Body);
  if JData = nil then
  begin
    LogErr('[API] GHGetContents: JSON parse failed');
    Exit;
  end;
  try
    if not (JData is TJSONArray) then
    begin
      // Single file object (not a directory listing)
      LogMsg('[API] GHGetContents: response is a single object (not array) ' +
        '- treating as empty directory listing');
      Result := True;
      Exit;
    end;
    JArr := TJSONArray(JData);
    LogMsg('[API] GHGetContents: ' + IntToStr(JArr.Count) + ' entries');

    SetLength(Entries, JArr.Count);
    for I := 0 to JArr.Count - 1 do
    begin
      if not (JArr[I] is TJSONObject) then Continue;
      JItem := TJSONObject(JArr[I]);
      Entries[I].Name        := JObjStr(JItem, 'name');
      Entries[I].Path        := JObjStr(JItem, 'path');
      Entries[I].EntryType   := JObjStr(JItem, 'type');
      Entries[I].SHA         := JObjStr(JItem, 'sha');
      Entries[I].Size        := JObjInt(JItem, 'size');
      Entries[I].IsDir       := (Entries[I].EntryType = 'dir');
      Entries[I].DownloadURL := JObjStr(JItem, 'download_url');
    end;
    Result := True;
  finally
    JData.Free;
  end;
end;

// ---------------------------------------------------------------------------

function GHDownloadFile(const Owner, Repo, Branch, FilePath, Token: string;
  const LocalPath: WideString;
  PluginNr: Integer; ProgressCb: TProgressProc;
  RemoteNameA, LocalNameA: PAnsiChar): Boolean;
var
  Path       : string;
  Body       : string;
  Status     : Integer;
  JData      : TJSONData;
  JObj       : TJSONObject;
  Encoding   : string;
  B64Content : string;
  RawBytes   : AnsiString;
  DownURL    : string;
  hFile      : THandle;
  Written    : DWORD;
begin
  Result := False;

  Path := '/repos/' + UrlEncodePath(Owner) + '/' +
    UrlEncodePath(Repo) + '/contents/' +
    UrlEncodePath(FilePath) + '?ref=' + UrlEncodePath(Branch);

  LogMsg('[API] GHDownloadFile -> GET ' + Path);
  Body := HttpGet(Path, Token, Status);

  if Status <> 200 then
  begin
    LogErr('[API] GHDownloadFile: HTTP ' + IntToStr(Status) +
      ' - ' + GitHubErrMsg(Body));
    Exit;
  end;

  JData := ParseJSON(Body);
  if JData = nil then begin LogErr('[API] GHDownloadFile: JSON parse failed'); Exit; end;
  try
    if not (JData is TJSONObject) then
    begin
      LogErr('[API] GHDownloadFile: expected JSON object, got ' + JData.ClassName);
      Exit;
    end;
    JObj     := TJSONObject(JData);
    Encoding := JObjStr(JObj, 'encoding');
    DownURL  := JObjStr(JObj, 'download_url');
    LogMsg('[API] GHDownloadFile: encoding=' + Encoding +
      ' download_url=' + Copy(DownURL, 1, 80));

    if Encoding = 'base64' then
    begin
      B64Content := JObjStr(JObj, 'content');
      B64Content := StringReplace(B64Content, #10, '', [rfReplaceAll]);
      B64Content := StringReplace(B64Content, #13, '', [rfReplaceAll]);
      B64Content := StringReplace(B64Content, ' ',  '', [rfReplaceAll]);
      LogMsg('[API] GHDownloadFile: base64 content length=' +
        IntToStr(Length(B64Content)));

      if Assigned(ProgressCb) then
        ProgressCb(PluginNr, RemoteNameA, LocalNameA, 50);

      RawBytes := DecodeStringBase64(B64Content);
      LogMsg('[API] GHDownloadFile: decoded to ' + IntToStr(Length(RawBytes)) +
        ' bytes, writing to local file');

      hFile := CreateFileW(PWideChar(LocalPath), GENERIC_WRITE, 0, nil,
        CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
      if hFile = INVALID_HANDLE_VALUE then
      begin
        LogErr('[API] GHDownloadFile: CreateFile FAILED, err=' +
          IntToStr(GetLastError));
        Exit;
      end;
      try
        Written := 0;
        if Length(RawBytes) > 0 then
          WriteFile(hFile, RawBytes[1], Length(RawBytes), Written, nil);
        LogMsg('[API] GHDownloadFile: wrote ' + IntToStr(Written) + ' bytes OK');
        Result := True;
        if Assigned(ProgressCb) then
          ProgressCb(PluginNr, RemoteNameA, LocalNameA, 100);
      finally
        CloseHandle(hFile);
        if not Result then DeleteFileW(PWideChar(LocalPath));
      end;
    end
    else if DownURL <> '' then
    begin
      LogMsg('[API] GHDownloadFile: large file, using DownloadURL');
      Result := HttpDownloadToFile(DownURL, Token, LocalPath,
                                   PluginNr, ProgressCb, RemoteNameA, LocalNameA);
    end
    else
      LogErr('[API] GHDownloadFile: unknown encoding "' + Encoding +
        '" and no download_url - cannot download');
  finally
    JData.Free;
  end;
end;

// ===========================================================================
//  Cleanup
// ===========================================================================
finalization
  if (GInetSession <> nil) and Assigned(FnInternetCloseHandle) then
  begin
    FnInternetCloseHandle(GInetSession);
    GInetSession := nil;
  end;
  if GWinInetLib <> 0 then
  begin
    FreeLibrary(GWinInetLib);
    GWinInetLib := 0;
  end;

end.
