unit uWfxMain;
{ Main implementation unit for the GitHubFS WFX plugin.

  Layout follows the proven tcchibiofs pattern:
    - All exported Fs* functions live here
    - The .lpr only contains an exports clause
    - ANSI-only exports (TC 64-bit falls back to ANSI just fine for our case;
      GitHub repo paths are ASCII-safe anyway)
    - The MODE Delphi directive below ensures FPC compatibility
    - PFindContext via New/Dispose, no class indirection
}

{$IFDEF FPC}{$MODE Delphi}{$ENDIF}

interface

uses
  Windows, SysUtils,
  fsplugin, GitHubTypes, GitHubAPI, PluginConfig, VirtualFS, ConfigDlg, Logger;

{ Mandatory exports }
function FsInit(PluginNr: Integer;
                pProgressProc: TProgressProc;
                pLogProc:      TLogProc;
                pRequestProc:  TRequestProc): Integer; stdcall;

function FsFindFirst(Path: PAnsiChar;
                     var FindData: TWin32FindDataA): THandle; stdcall;

function FsFindNext(Hdl: THandle;
                    var FindData: TWin32FindDataA): LongBool; stdcall;

function FsFindClose(Hdl: THandle): Integer; stdcall;

{ Optional exports }
procedure FsGetDefRootName(DefRootName: PAnsiChar; MaxLen: Integer); stdcall;
procedure FsSetDefaultParams(dps: pFsDefaultParamStruct); stdcall;
function  FsLinksToLocalFiles: LongBool; stdcall;
function  FsExecuteFile(MainWin: THandle;
                        RemoteName, Verb: PAnsiChar): Integer; stdcall;
function  FsGetFile(RemoteName, LocalName: PAnsiChar;
                    CopyFlags: Integer;
                    RemoteInfo: pRemoteInfo): Integer; stdcall;

implementation

{$WARN 5083 OFF}  // pointer/ordinal conversion - safe in Win32 code

// ---------------------------------------------------------------------------
//  Shared state
// ---------------------------------------------------------------------------
var
  GPluginNr   : Integer      = 0;
  GProgressCb : TProgressProc = nil;
  GLogCb      : TLogProc     = nil;
  GRequestCb  : TRequestProc = nil;

// ---------------------------------------------------------------------------
//  Find iterator context (allocated by FsFindFirst, freed by FsFindClose)
// ---------------------------------------------------------------------------
type
  PFindContext = ^TFindContext;
  TFindContext = record
    Entries : TVFSEntryArray;
    Index   : Integer;
  end;

// ---------------------------------------------------------------------------
//  Helpers
// ---------------------------------------------------------------------------
procedure LogMsgA(MsgType: Integer; const S: AnsiString);
begin
  if Assigned(GLogCb) then
    GLogCb(GPluginNr, MsgType, PAnsiChar(S));
end;

function PluginPathFromPChar(P: PAnsiChar): AnsiString;
begin
  if P = nil then
    Result := ''
  else
    Result := AnsiString(P);
end;

procedure FillFindData(var FD: TWin32FindDataA; const E: TVFSEntry);
var
  L : Integer;
  Name : AnsiString;
begin
  FillChar(FD, SizeOf(FD), 0);
  if E.IsDir then
    FD.dwFileAttributes := FILE_ATTRIBUTE_DIRECTORY
  else
    FD.dwFileAttributes := FILE_ATTRIBUTE_NORMAL;

  if not E.IsDir then
  begin
    FD.nFileSizeLow  := DWORD(E.Size and $FFFFFFFF);
    FD.nFileSizeHigh := DWORD(E.Size shr 32);
  end;

  // E.Name is WideString in our model - convert to AnsiString (UTF-8 OK for ASCII)
  Name := AnsiString(E.Name);
  L := Length(Name);
  if L > SizeOf(FD.cFileName) - 1 then
    L := SizeOf(FD.cFileName) - 1;
  if L > 0 then
    Move(Name[1], FD.cFileName[0], L);
  FD.cFileName[L] := #0;
end;

// ===========================================================================
//  FsInit  -  mandatory
// ===========================================================================
function FsInit(PluginNr: Integer;
                pProgressProc: TProgressProc;
                pLogProc:      TLogProc;
                pRequestProc:  TRequestProc): Integer; stdcall;
begin
  GPluginNr   := PluginNr;
  GProgressCb := pProgressProc;
  GLogCb      := pLogProc;
  GRequestCb  := pRequestProc;
  Result := 0;
end;

// ===========================================================================
//  FsGetDefRootName  -  shown in Network Neighborhood
// ===========================================================================
procedure FsGetDefRootName(DefRootName: PAnsiChar; MaxLen: Integer); stdcall;
const
  RN: AnsiString = 'GitHub Repositories';
var
  L : Integer;
  P : PAnsiChar;
begin
  L := Length(RN);
  if L > MaxLen - 1 then L := MaxLen - 1;
  if L > 0 then
    Move(RN[1], DefRootName^, L);
  P := DefRootName;
  Inc(P, L);
  P^ := #0;
end;

// ===========================================================================
//  FsSetDefaultParams  -  TC tells us where its INI lives
// ===========================================================================
procedure FsSetDefaultParams(dps: pFsDefaultParamStruct); stdcall;
begin
  if dps = nil then Exit;
  // 1. Derive plugin folder from the DLL path, set INI + log paths
  PluginConfig.SetConfigPath(string(AnsiString(dps^.DefaultIniName)));
  // 2. Now that the log path is known, initialise the logger
  //    (FsInit already stored GPluginNr; nil = no TC panel forwarding for now)
  Logger.LogInit(GPluginNr, nil, PluginConfig.GetLogPath);
  Logger.LogMsg('[INIT] FsSetDefaultParams: log file opened');
  Logger.LogMsg('[INIT] Plugin version 1.0');
end;

// ===========================================================================
//  FsLinksToLocalFiles  -  we are a virtual FS, not local
// ===========================================================================
function FsLinksToLocalFiles: LongBool; stdcall;
begin
  Result := False;
end;

// ===========================================================================
//  FsFindFirst  -  build entry list, return iterator handle
// ===========================================================================
function FsFindFirst(Path: PAnsiChar;
                     var FindData: TWin32FindDataA): THandle; stdcall;
var
  P   : AnsiString;
  PP  : TParsedPath;
  Ctx : PFindContext;
  Ents: TVFSEntryArray;
begin
  Result := THandle(INVALID_HANDLE_VALUE);
  FillChar(FindData, SizeOf(FindData), 0);
  P := PluginPathFromPChar(Path);

  try
    PP   := VirtualFS.ParsePath(WideString(P));
    Ents := VirtualFS.BuildEntries(PP);
  except
    on E: Exception do
    begin
      LogMsgA(msgtype_importanterror,
              'FsFindFirst exception: ' + AnsiString(E.Message));
      SetLastError(ERROR_GEN_FAILURE);
      Exit;
    end;
  end;

  if Length(Ents) = 0 then
  begin
    SetLastError(ERROR_NO_MORE_FILES);
    Exit;
  end;

  New(Ctx);
  Ctx^.Entries := Ents;
  Ctx^.Index   := 0;

  FillFindData(FindData, Ents[0]);
  Ctx^.Index := 1;

  Result := THandle(Ctx);
end;

// ===========================================================================
//  FsFindNext  -  return next entry from iterator
// ===========================================================================
function FsFindNext(Hdl: THandle;
                    var FindData: TWin32FindDataA): LongBool; stdcall;
var
  Ctx : PFindContext;
begin
  Result := False;
  if Hdl = THandle(INVALID_HANDLE_VALUE) then Exit;
  if Hdl = 0 then Exit;
  Ctx := PFindContext(Hdl);
  if Ctx^.Index >= Length(Ctx^.Entries) then Exit;
  FillFindData(FindData, Ctx^.Entries[Ctx^.Index]);
  Inc(Ctx^.Index);
  Result := True;
end;

// ===========================================================================
//  FsFindClose  -  free iterator
// ===========================================================================
function FsFindClose(Hdl: THandle): Integer; stdcall;
var
  Ctx : PFindContext;
begin
  Result := 0;
  if Hdl = THandle(INVALID_HANDLE_VALUE) then Exit;
  if Hdl = 0 then Exit;
  Ctx := PFindContext(Hdl);
  SetLength(Ctx^.Entries, 0);
  Dispose(Ctx);
end;

// ===========================================================================
//  FsExecuteFile  -  intercept "[Configuration]" pseudo-file
// ===========================================================================
function FsExecuteFile(MainWin: THandle;
                       RemoteName, Verb: PAnsiChar): Integer; stdcall;
var
  RN          : AnsiString;
  NewName     : string;
  NewPath     : AnsiString;
begin
  RN := PluginPathFromPChar(RemoteName);

  if RN = '\[Configuration]' then
  begin
    ConfigDlg.ShowConfigDialog(HWND(MainWin));
    Result := FS_EXEC_OK;
    Exit;
  end;

  if RN = '\[Quick add]' then
  begin
    NewName := '';
    if ConfigDlg.ShowQuickAddDialog(HWND(MainWin), NewName) and (NewName <> '') then
    begin
      NewPath := AnsiString('\' + NewName);
      if Length(NewPath) < MAX_PATH then
      begin
        Move(NewPath[1], RemoteName^, Length(NewPath));
        RemoteName[Length(NewPath)] := #0;
      end;
      Result := FS_EXEC_SYMLINK;
    end
    else
      Result := FS_EXEC_OK;
    Exit;
  end;

  Result := FS_EXEC_YOURSELF;
end;

// ===========================================================================
//  FsGetFile  -  download a file from GitHub to local disk
// ===========================================================================
function FsGetFile(RemoteName, LocalName: PAnsiChar;
                   CopyFlags: Integer;
                   RemoteInfo: pRemoteInfo): Integer; stdcall;
var
  RN, LN : AnsiString;
begin
  Result := FS_FILE_NOTSUPPORTED;
  RN := PluginPathFromPChar(RemoteName);
  LN := PluginPathFromPChar(LocalName);

  // Signal start to TC progress bar
  if Assigned(GProgressCb) then
    GProgressCb(GPluginNr, PAnsiChar(RN), PAnsiChar(LN), 0);

  try
    Result := VirtualFS.GetFile(WideString(RN), WideString(LN),
                                CopyFlags, GPluginNr, GProgressCb);
  except
    on E: Exception do
    begin
      LogMsgA(msgtype_importanterror,
              'FsGetFile exception: ' + AnsiString(E.Message));
      Result := FS_FILE_READERROR;
    end;
  end;

  // Signal completion (100%) or cancellation
  if Assigned(GProgressCb) then
  begin
    if Result = FS_FILE_OK then
      GProgressCb(GPluginNr, PAnsiChar(RN), PAnsiChar(LN), 100)
    else
      GProgressCb(GPluginNr, PAnsiChar(RN), PAnsiChar(LN), -1);
  end;
end;

end.
