{$IFDEF FPC}{$MODE Delphi}{$ENDIF}
(*
  GitHubTypes.pas - shared data models for GitHubFS WFX plugin

  Virtual path hierarchy exposed in TC:
    \                            -> root: all configured repos + [Configuration]
    \<DisplayName>               -> branches of that repo (each is a folder)
    \<DisplayName>\<branch>      -> root tree of that branch
    \<DisplayName>\<branch>\...  -> sub-directories and files

  GitHub API endpoints used:
    GET /repos/(owner)/(repo)/branches?per_page=100
    GET /repos/(owner)/(repo)/contents/(path)?ref=(branch)
    GET /repos/(owner)/(repo)/contents/(path)?ref=(branch)  (single file -> base64)
    GET /user                                                 (connection test)
*)
unit GitHubTypes;

interface

// ---------------------------------------------------------------------------
//  Repo configuration entry (one per configured repository)
// ---------------------------------------------------------------------------
type
  TRepoConfig = record
    DisplayName    : string;   // unique label shown in TC (UTF-8)
    Owner          : string;   // GitHub owner / organisation (ASCII)
    RepoName       : string;   // GitHub repository name (ASCII)
    EncryptedToken : string;   // DPAPI-encrypted token, Base64-encoded
    DefaultBranch  : string;   // if set, skip branch list and go directly here
    Enabled        : Boolean;
  end;
  TRepoConfigArray = array of TRepoConfig;

// ---------------------------------------------------------------------------
//  Branch list entry
// ---------------------------------------------------------------------------
  TBranchInfo = record
    Name      : string;   // branch name (UTF-8)
    CommitSHA : string;   // head commit SHA
  end;
  TBranchArray = array of TBranchInfo;

// ---------------------------------------------------------------------------
//  Content entry (from GitHub Contents API)
// ---------------------------------------------------------------------------
  TContentEntry = record
    Name        : string;   // file / directory name (UTF-8)
    Path        : string;   // full relative path in repo
    EntryType   : string;   // 'file' | 'dir'
    SHA         : string;
    Size        : Int64;
    IsDir       : Boolean;
    DownloadURL : string;   // raw URL; empty for private dirs
  end;
  TContentArray = array of TContentEntry;

// ---------------------------------------------------------------------------
//  Parsed virtual path (result of ParseVirtualPath)
// ---------------------------------------------------------------------------
  TPathLevel = (
    plRoot,    // \
    plRepo,    // \DisplayName
    plBranch,  // \DisplayName\branch
    plTree     // \DisplayName\branch\subpath...
  );

  TParsedPath = record
    Level           : TPathLevel;
    RepoDisplayName : string;   // valid at plRepo and below
    BranchName      : string;   // valid at plBranch and below
    TreePath        : string;   // valid at plTree; forward-slash separated
  end;

// ---------------------------------------------------------------------------
//  Virtual filesystem entry (used by iterator)
// ---------------------------------------------------------------------------
  TVFSEntry = record
    Name    : WideString;
    IsDir   : Boolean;
    Size    : Int64;
    ModTime : TDateTime;   // 0 = unknown / not set
  end;
  TVFSEntryArray = array of TVFSEntry;

implementation

end.
