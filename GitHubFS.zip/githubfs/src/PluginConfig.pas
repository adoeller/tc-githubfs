{$IFDEF FPC}{$MODE Delphi}{$ENDIF}
{
  PluginConfig.pas – INI-based configuration + Windows DPAPI token encryption

  INI layout (githubfs.ini):
    [Settings]
    Count=N
    LogEnabled=1

    [Repo1]
    DisplayName=MyProject        ; UTF-8, unique
    Owner=octocat                ; GitHub owner / org
    Repo=Hello-World             ; repository name
    Token=<DPAPI+Base64>         ; never stored plain-text
    Enabled=1

  Token encryption:
    CryptProtectData  (crypt32.dll) – machine+user scoped DPAPI encryption
    Fallback prefix "XOR:" + base64(xor(token, fixedKey)) if DPAPI unavailable
    (DPAPI is always available on modern Windows; fallback is a last resort)
}
unit PluginConfig;

interface

uses
  Windows, SysUtils, IniFiles, GitHubTypes, Logger;

{ Must be called from FsSetDefaultParams with TC's default INI path.
  Derives "githubfs.ini" in the same directory. }
procedure SetConfigPath(const TCDefaultIniPath: string);

{ Returns the full path of the plugin's own INI file. }
function GetConfigPath: string;

{ Returns the full path of the diagnostic log file. }
function GetLogPath: string;

{ Load all configured repositories from INI.
  Returns empty array if file does not exist yet. }
function LoadRepos: TRepoConfigArray;

{ Save repository list to INI (overwrites previous content). }
procedure SaveRepos(const Repos: TRepoConfigArray);

{ Load / save the global fallback access token. }
function  LoadGlobalToken: string;
procedure SaveGlobalToken(const PlainToken: string);

{ Returns the decrypted token for a repo: uses repo token if set,
  falls back to the global token. }
function  GetEffectiveToken(const RepoEncryptedToken: string): string;

{ Encrypt a plain-text token for storage (DPAPI, then Base64). }
function EncryptToken(const PlainToken: string): string;

{ Decrypt a stored token (Base64, then DPAPI). }
function DecryptToken(const StoredToken: string): string;

implementation

{$WARN 5083 OFF}  // pointer/ordinal conversion - safe in our Win32 code

uses
  base64, Classes;

// ---------------------------------------------------------------------------
//  Globals
// ---------------------------------------------------------------------------
var
  GConfigPath : string;
  GLogPath    : string;

const
  XOR_FALLBACK_PREFIX = 'XOR:';
  // 32-byte fixed XOR key used only as DPAPI fallback
  XOR_KEY : array[0..31] of Byte = (
    $4B,$A9,$17,$E3,$2C,$85,$F1,$3D,$76,$BA,$09,$CC,$50,$E7,$23,$9F,
    $B2,$04,$6D,$A1,$38,$7E,$C5,$12,$D9,$4F,$86,$23,$A8,$61,$FD,$2B);

// ---------------------------------------------------------------------------
//  DPAPI dynamic binding
// ---------------------------------------------------------------------------
type
  TDataBlob = record
    cbData : DWORD;
    pbData : PByte;
  end;
  PDataBlob = ^TDataBlob;

var
  GCrypt32     : HMODULE;
  GCryptReady  : Boolean;

  FnCryptProtect   : function(pDataIn: PDataBlob; szDataDescr: PWideChar;
                       pOptionalEntropy: PDataBlob; pvReserved: Pointer;
                       pPromptStruct: Pointer; dwFlags: DWORD;
                       pDataOut: PDataBlob): BOOL; stdcall;
  FnCryptUnprotect : function(pDataIn: PDataBlob; ppszDataDescr: Pointer;
                       pOptionalEntropy: PDataBlob; pvReserved: Pointer;
                       pPromptStruct: Pointer; dwFlags: DWORD;
                       pDataOut: PDataBlob): BOOL; stdcall;

procedure EnsureCrypt32;
begin
  if GCryptReady then Exit;
  GCrypt32 := LoadLibraryA('crypt32.dll');
  if GCrypt32 = 0 then
  begin
    LogErr('crypt32.dll load failed');
    Exit;
  end;
  @FnCryptProtect := GetProcAddress(GCrypt32, 'CryptProtectData');
  @FnCryptUnprotect := GetProcAddress(GCrypt32, 'CryptUnprotectData');
  if Assigned(FnCryptProtect) and Assigned(FnCryptUnprotect) then
    GCryptReady := True
  else
    LogErr('crypt32: procs not found');
end;

// ---------------------------------------------------------------------------
//  XOR fallback (low security – used only if DPAPI is unavailable)
// ---------------------------------------------------------------------------
function XorToken(const S: string): string;
var
  I : Integer;
begin
  Result := '';
  SetLength(Result, Length(S));
  for I := 1 to Length(S) do
    Result[I] := Char(Byte(S[I]) xor XOR_KEY[(I - 1) mod 32]);
end;

// ---------------------------------------------------------------------------
//  Public API
// ---------------------------------------------------------------------------
procedure SetConfigPath(const TCDefaultIniPath: string);
var
  ModulePath : array[0..MAX_PATH] of WideChar;
  PluginDir  : string;
begin
  // TCDefaultIniPath intentionally ignored - we use the DLL's own path instead
  if TCDefaultIniPath = '' then ;  // silence "parameter not used" hint
  ModulePath[0] := WideChar(0);  // zero-terminate before use
  FillChar(ModulePath, SizeOf(ModulePath), 0);
  GetModuleFileNameW(HInstance, ModulePath, MAX_PATH);
  PluginDir   := ExtractFilePath(string(WideString(ModulePath)));
  GConfigPath := PluginDir + 'githubfs.ini';
  GLogPath    := PluginDir + 'githubfs.log';
  // Note: LogInit is called by uWfxMain.FsSetDefaultParams immediately after
  // this returns, so LogMsg is not yet safe to call here.
end;

function GetConfigPath: string;
begin
  if GConfigPath <> '' then
    Result := GConfigPath
  else
    Result := GetTempDir + 'githubfs.ini';
end;

function GetLogPath: string;
begin
  if GLogPath <> '' then
    Result := GLogPath
  else
    Result := GetTempDir + 'githubfs.log';
end;

function LoadRepos: TRepoConfigArray;
var
  Ini   : TIniFile;
  Count : Integer;
  I     : Integer;
  Sec   : string;
begin
  Result := nil;
  if not FileExists(GetConfigPath) then Exit;
  Ini := TIniFile.Create(GetConfigPath);
  try
    Count := Ini.ReadInteger('Settings', 'Count', 0);
    if Count <= 0 then Exit;
    SetLength(Result, Count);
    for I := 0 to Count - 1 do
    begin
      Sec              := 'Repo' + IntToStr(I + 1);
      Result[I].DisplayName    := Ini.ReadString(Sec, 'DisplayName', '');
      Result[I].Owner          := Ini.ReadString(Sec, 'Owner', '');
      Result[I].RepoName       := Ini.ReadString(Sec, 'Repo', '');
      Result[I].EncryptedToken := Ini.ReadString(Sec, 'Token', '');
      Result[I].DefaultBranch  := Ini.ReadString(Sec, 'DefaultBranch', '');
      Result[I].Enabled        := Ini.ReadBool(Sec, 'Enabled', True);
    end;
  finally
    Ini.Free;
  end;
end;

procedure SaveRepos(const Repos: TRepoConfigArray);
var
  Ini : TIniFile;
  I   : Integer;
  Sec : string;
begin
  Ini := TIniFile.Create(GetConfigPath);
  try
    // Clear old repo sections
    Ini.WriteInteger('Settings', 'Count', Length(Repos));
    for I := 0 to Length(Repos) - 1 do
    begin
      Sec := 'Repo' + IntToStr(I + 1);
      Ini.WriteString(Sec, 'DisplayName', Repos[I].DisplayName);
      Ini.WriteString(Sec, 'Owner',       Repos[I].Owner);
      Ini.WriteString(Sec, 'Repo',        Repos[I].RepoName);
      Ini.WriteString(Sec, 'Token',       Repos[I].EncryptedToken);
      Ini.WriteString(Sec, 'DefaultBranch', Repos[I].DefaultBranch);
      Ini.WriteBool(Sec,   'Enabled',     Repos[I].Enabled);
    end;
    Ini.UpdateFile;
  finally
    Ini.Free;
  end;
end;

// ---------------------------------------------------------------------------

function EncryptToken(const PlainToken: string): string;
var
  DataIn  : TDataBlob;
  DataOut : TDataBlob;
  Desc    : WideString;
  Raw     : AnsiString;
begin
  Raw    := '';
  Result := '';
  if PlainToken = '' then Exit;
  EnsureCrypt32;

  if GCryptReady then
  begin
    DataIn.cbData  := Length(PlainToken);
    DataIn.pbData  := PByte(PAnsiChar(AnsiString(PlainToken)));
    DataOut.cbData := 0;
    DataOut.pbData := nil;
    Desc := 'GitHubFSToken';

    if FnCryptProtect(@DataIn, PWideChar(Desc), nil, nil, nil, 0, @DataOut)
      and (DataOut.cbData > 0) then
    begin
      SetLength(Raw, DataOut.cbData);
      Move(DataOut.pbData^, Raw[1], DataOut.cbData);
      Result := EncodeStringBase64(Raw);
      LocalFree(HLOCAL(PtrUInt(DataOut.pbData)));
    end else
      LogErr('CryptProtectData failed: ' + IntToStr(GetLastError));
  end;  // if GCryptReady

  if Result = '' then
  begin
    // XOR fallback
    Result := XOR_FALLBACK_PREFIX +
      EncodeStringBase64(AnsiString(XorToken(PlainToken)));
  end;
end;

function DecryptToken(const StoredToken: string): string;
var
  DataIn  : TDataBlob;
  DataOut : TDataBlob;
  Raw     : AnsiString;
begin
  Result := '';
  if StoredToken = '' then Exit;

  // XOR fallback path
  if Copy(StoredToken, 1, Length(XOR_FALLBACK_PREFIX)) = XOR_FALLBACK_PREFIX then
  begin
    try
      Raw    := DecodeStringBase64(
        AnsiString(Copy(StoredToken, Length(XOR_FALLBACK_PREFIX) + 1,
          Length(StoredToken))));
      Result := XorToken(string(Raw));
    except
      LogErr('DecryptToken XOR fallback failed');
    end;
    Exit;
  end;

  EnsureCrypt32;
  if not GCryptReady then Exit;

  try
    Raw := DecodeStringBase64(AnsiString(StoredToken));
  except
    LogErr('DecryptToken: base64 decode failed');
    Exit;
  end;
  if Raw = '' then Exit;

  DataIn.cbData  := Length(Raw);
  DataIn.pbData  := PByte(PAnsiChar(Raw));
  DataOut.cbData := 0;
  DataOut.pbData := nil;

  if FnCryptUnprotect(@DataIn, nil, nil, nil, nil, 0, @DataOut)
    and (DataOut.cbData > 0) then
  begin
    SetLength(Raw, DataOut.cbData);
    Move(DataOut.pbData^, Raw[1], DataOut.cbData);
    Result := string(Raw);
    LocalFree(HLOCAL(PtrUInt(DataOut.pbData)));
  end else
    LogErr('CryptUnprotectData failed: ' + IntToStr(GetLastError));
end;

// ---------------------------------------------------------------------------
//  Global token fallback
// ---------------------------------------------------------------------------

function LoadGlobalToken: string;
var
  Ini : TIniFile;
begin
  Result := '';
  if not FileExists(GetConfigPath) then Exit;
  Ini := TIniFile.Create(GetConfigPath);
  try
    Result := DecryptToken(Ini.ReadString('Settings', 'GlobalToken', ''));
  finally
    Ini.Free;
  end;
end;

procedure SaveGlobalToken(const PlainToken: string);
var
  Ini : TIniFile;
begin
  Ini := TIniFile.Create(GetConfigPath);
  try
    if PlainToken <> '' then
      Ini.WriteString('Settings', 'GlobalToken', EncryptToken(PlainToken))
    else
      Ini.DeleteKey('Settings', 'GlobalToken');
    Ini.UpdateFile;
  finally
    Ini.Free;
  end;
end;

function GetEffectiveToken(const RepoEncryptedToken: string): string;
begin
  if RepoEncryptedToken <> '' then
    Result := DecryptToken(RepoEncryptedToken)
  else
    Result := LoadGlobalToken;
end;

// ---------------------------------------------------------------------------
initialization
  GConfigPath := '';
  GLogPath    := '';
  GCrypt32    := 0;
  GCryptReady := False;

finalization
  if GCrypt32 <> 0 then
  begin
    FreeLibrary(GCrypt32);
    GCrypt32 := 0;
  end;

end.
