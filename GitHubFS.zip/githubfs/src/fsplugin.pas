unit fsplugin;
{ Plugin definitions version 2.1 SE
  Official header by Christian Ghisler / Ghisler Software GmbH
  Source: https://ghisler.github.io/WFX-SDK/fsplugin.pas.htm

  Enthaelt Konstanten, Typen und Callback-Definitionen fuer
  Total Commander File System Plugins (WFX). }

interface

uses
  Windows;

{ ids for FsGetFile / FsPutFile }
const
  FS_FILE_OK                   = 0;
  FS_FILE_EXISTS               = 1;
  FS_FILE_NOTFOUND             = 2;
  FS_FILE_READERROR            = 3;
  FS_FILE_WRITEERROR           = 4;
  FS_FILE_USERABORT            = 5;
  FS_FILE_NOTSUPPORTED         = 6;
  FS_FILE_EXISTSRESUMEALLOWED  = 7;

  FS_EXEC_OK                   =  0;
  FS_EXEC_ERROR                =  1;
  FS_EXEC_YOURSELF             = -1;
  FS_EXEC_SYMLINK              = -2;

  FS_COPYFLAGS_OVERWRITE               = 1;
  FS_COPYFLAGS_RESUME                  = 2;
  FS_COPYFLAGS_MOVE                    = 4;
  FS_COPYFLAGS_EXISTS_SAMECASE         = 8;
  FS_COPYFLAGS_EXISTS_DIFFERENTCASE    = 16;

{ flags for tRequestProc }
  RT_Other                = 0;
  RT_UserName             = 1;
  RT_Password             = 2;
  RT_Account              = 3;
  RT_UserNameFirewall     = 4;
  RT_PasswordFirewall     = 5;
  RT_TargetDir            = 6;
  RT_URL                  = 7;
  RT_MsgOK                = 8;
  RT_MsgYesNo             = 9;
  RT_MsgOKCancel          = 10;

{ flags for tLogProc }
  msgtype_connect          = 1;
  msgtype_disconnect       = 2;
  msgtype_details          = 3;
  msgtype_transfercomplete = 4;
  msgtype_connectcomplete  = 5;
  msgtype_importanterror   = 6;
  msgtype_operationcomplete= 7;

{ flags for FsStatusInfo }
  FS_STATUS_START                 = 0;
  FS_STATUS_END                   = 1;

  FS_STATUS_OP_LIST               = 1;
  FS_STATUS_OP_GET_SINGLE         = 2;
  FS_STATUS_OP_GET_MULTI          = 3;
  FS_STATUS_OP_PUT_SINGLE         = 4;
  FS_STATUS_OP_PUT_MULTI          = 5;
  FS_STATUS_OP_RENMOV_SINGLE      = 6;
  FS_STATUS_OP_RENMOV_MULTI       = 7;
  FS_STATUS_OP_DELETE             = 8;
  FS_STATUS_OP_ATTRIB             = 9;
  FS_STATUS_OP_MKDIR              = 10;
  FS_STATUS_OP_EXEC               = 11;
  FS_STATUS_OP_CALCSIZE           = 12;
  FS_STATUS_OP_SEARCH             = 13;
  FS_STATUS_OP_SEARCH_TEXT        = 14;
  FS_STATUS_OP_SYNC_SEARCH        = 15;
  FS_STATUS_OP_SYNC_GET           = 16;
  FS_STATUS_OP_SYNC_PUT           = 17;
  FS_STATUS_OP_SYNC_DELETE        = 18;
  FS_STATUS_OP_GET_MULTI_THREAD   = 19;
  FS_STATUS_OP_PUT_MULTI_THREAD   = 20;

{ Flags for FsExtractCustomIcon }
  FS_ICONFLAG_SMALL               = 1;
  FS_ICONFLAG_BACKGROUND          = 2;

  FS_ICON_USEDEFAULT              = 0;
  FS_ICON_EXTRACTED               = 1;
  FS_ICON_EXTRACTED_DESTROY       = 2;
  FS_ICON_DELAYED                 = 3;

  FS_BITMAP_NONE                     = 0;
  FS_BITMAP_EXTRACTED                = 1;
  FS_BITMAP_EXTRACT_YOURSELF         = 2;
  FS_BITMAP_EXTRACT_YOURSELF_ANDDELETE = 3;
  FS_BITMAP_CACHE                    = 256;

{ Flags for crypto callback function }
  FS_CRYPT_SAVE_PASSWORD         = 1;
  FS_CRYPT_LOAD_PASSWORD         = 2;
  FS_CRYPT_LOAD_PASSWORD_NO_UI   = 3;
  FS_CRYPT_COPY_PASSWORD         = 4;
  FS_CRYPT_MOVE_PASSWORD         = 5;
  FS_CRYPT_DELETE_PASSWORD       = 6;

  FS_CRYPTOPT_MASTERPASS_SET     = 1;

  BG_DOWNLOAD = 1;
  BG_UPLOAD   = 2;
  BG_ASK_USER = 4;

type
  tRemoteInfo = record
    SizeLow, SizeHigh: LongInt;
    LastWriteTime:     TFileTime;
    Attr:              LongInt;
  end;
  pRemoteInfo = ^tRemoteInfo;

  tFsDefaultParamStruct = record
    size,
    PluginInterfaceVersionLow,
    PluginInterfaceVersionHi: LongInt;
    DefaultIniName: array[0..MAX_PATH-1] of AnsiChar;
  end;
  pFsDefaultParamStruct = ^tFsDefaultParamStruct;

  { callback functions - ANSI }
  TProgressProc = function(PluginNr: Integer;
                           SourceName, TargetName: PAnsiChar;
                           PercentDone: Integer): Integer; stdcall;
  TLogProc      = procedure(PluginNr, MsgType: Integer;
                            LogString: PAnsiChar); stdcall;
  TRequestProc  = function(PluginNr, RequestType: Integer;
                           CustomTitle, CustomText, ReturnedText: PAnsiChar;
                           maxlen: Integer): LongBool; stdcall;

  { callback functions - UNICODE }
  TProgressProcW = function(PluginNr: Integer;
                            SourceName, TargetName: PWideChar;
                            PercentDone: Integer): Integer; stdcall;
  TLogProcW      = procedure(PluginNr, MsgType: Integer;
                             LogString: PWideChar); stdcall;
  TRequestProcW  = function(PluginNr, RequestType: Integer;
                            CustomTitle, CustomText, ReturnedText: PWideChar;
                            maxlen: Integer): LongBool; stdcall;

implementation

end.
