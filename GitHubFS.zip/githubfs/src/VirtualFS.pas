unit VirtualFS;
{ Path parsing and entry list building for GitHubFS WFX plugin.
  Returns logical entries (TVFSEntryArray) - the WFX layer in uWfxMain
  converts these to TWin32FindDataA. }

{$IFDEF FPC}{$MODE Delphi}{$ENDIF}

interface

uses
  SysUtils,
  fsplugin, GitHubTypes, GitHubAPI, GitHubCache, PluginConfig, Logger;

{ Parse a TC backslash path into a structured TParsedPath. }
function ParsePath(const Path: WideString): TParsedPath;

{ Build the entry list for a parsed path (handles all 4 levels:
  root, repo, branch, tree). Returns nil/empty array on error. }
function BuildEntries(const PP: TParsedPath): TVFSEntryArray;

{ Download a file from GitHub to local disk.
  Returns one of the FS_FILE_* constants from fsplugin. }
function GetFile(const RemoteName, LocalName: WideString;
                 CopyFlags: Integer;
                 PluginNr: Integer;
                 ProgressCb: TProgressProc): Integer;

implementation

{$WARN 5057 OFF}  // local var might not be init
{$WARN 5058 OFF}  // variable of managed type might not be init
{$WARN 5060 OFF}  // result of managed type not init

// ---------------------------------------------------------------------------
//  Path parsing
// ---------------------------------------------------------------------------
function ParsePath(const Path: WideString): TParsedPath;
var
  S     : string;
  Parts : array of string;
  Raw   : string;
  I     : Integer;
  Count : Integer;
begin
  {%H-}  // FillChar below initializes Result - suppress false managed-type warning
  Parts := nil;
  FillChar(Result, SizeOf(Result), 0);{%H+}
  Result.Level := plRoot;

  S := string(Path);

  while (Length(S) > 0) and (S[1] = '\') do
    Delete(S, 1, 1);
  while (Length(S) > 0) and (S[Length(S)] = '\') do
    SetLength(S, Length(S) - 1);

  if S = '' then Exit;

  Raw := '';
  for I := 1 to Length(S) do
  begin
    if S[I] = '\' then
    begin
      if Raw <> '' then
      begin
        SetLength(Parts, Length(Parts) + 1);
        Parts[High(Parts)] := Raw;
        Raw := '';
      end;
    end
    else
      Raw := Raw + S[I];
  end;
  if Raw <> '' then
  begin
    SetLength(Parts, Length(Parts) + 1);
    Parts[High(Parts)] := Raw;
  end;

  Count := Length(Parts);
  if Count = 0 then Exit;

  Result.RepoDisplayName := Parts[0];
  Result.Level := plRepo;

  if Count >= 2 then
  begin
    Result.BranchName := Parts[1];
    Result.Level := plBranch;
  end;

  if Count >= 3 then
  begin
    Result.TreePath := Parts[2];
    for I := 3 to Count - 1 do
      Result.TreePath := Result.TreePath + '/' + Parts[I];
    Result.Level := plTree;
  end;
end;

// ---------------------------------------------------------------------------
//  Lookup repo by display name
// ---------------------------------------------------------------------------
function FindRepo(const Repos: TRepoConfigArray;
                  const Name: string;
                  out Repo: TRepoConfig): Boolean;
var
  I : Integer;
begin
  Result := False;
  FillChar(Repo, SizeOf(Repo), 0);
  for I := 0 to High(Repos) do
    if Repos[I].DisplayName = Name then
    begin
      Repo := Repos[I];
      Result := True;
      Exit;
    end;
end;

// ---------------------------------------------------------------------------
//  DefaultBranch path helpers
//
//  When a repo has DefaultBranch="main", TC never sees the branch segment.
//  Paths are shifted one level:
//
//  WITHOUT DefaultBranch     WITH DefaultBranch="main"
//  plRepo  → show branches   plRepo  → show root of main
//  plBranch(branch=X) → X's root  plBranch(branch=X) → X is a PATH in main
//  plTree(branch=X,path=P)  plTree(branch=X,path=P) → branch=main, path=X/P
//
// ---------------------------------------------------------------------------

function EffectiveBranch(const PP: TParsedPath;
                         const Repo: TRepoConfig): string;
begin
  if Repo.DefaultBranch <> '' then
    Result := Repo.DefaultBranch          // always use configured branch
  else
    Result := PP.BranchName;              // branch is encoded in path
end;

function EffectivePath(const PP: TParsedPath;
                       const Repo: TRepoConfig): string;
begin
  if Repo.DefaultBranch <> '' then
  begin
    // PP.BranchName is actually the first path segment (not a real branch)
    case PP.Level of
      plRepo:   Result := '';
      plBranch: Result := PP.BranchName;  // e.g. "README.md" or "src"
      plTree:   Result := PP.BranchName + '/' + PP.TreePath; // e.g. "src/main.c"
    else        Result := '';
    end;
  end
  else
  begin
    case PP.Level of
      plBranch: Result := '';
      plTree:   Result := PP.TreePath;
    else        Result := '';
    end;
  end;
end;

// When DefaultBranch is set, a plBranch path may point to a file, not a dir.
// We need to know if PP refers to a downloadable file.
function IsFileLevel(const PP: TParsedPath;
                     const Repo: TRepoConfig): Boolean;
begin
  if Repo.DefaultBranch <> '' then
    // plBranch = something directly under repo root (could be file or dir)
    // plTree   = something deeper (could be file or dir)
    Result := (PP.Level = plBranch) or (PP.Level = plTree)
  else
    Result := PP.Level = plTree;
end;

// ---------------------------------------------------------------------------
//  BuildEntries - main per-level dispatcher
// ---------------------------------------------------------------------------
function BuildEntries(const PP: TParsedPath): TVFSEntryArray;
var
  Repos    : TRepoConfigArray;
  Branches : TBranchArray;
  Contents : TContentArray;
  {%H-}Repo     : TRepoConfig;{%H+}
  Token    : string;
  I        : Integer;
  {%H-}E        : TVFSEntry;{%H+}
  CE       : TContentEntry;
  Found    : Boolean;
  Branch   : string;
  Path     : string;
begin
  Result := nil;
  Repos := LoadRepos;

  case PP.Level of

    plRoot:
    begin
      // Root: [Configuration], [Quick add], then all enabled repos as folders
      SetLength(Result, 2);
      FillChar(Result[0], SizeOf(Result[0]), 0);
      Result[0].Name  := '[Configuration]';
      Result[0].IsDir := False;
      FillChar(Result[1], SizeOf(Result[1]), 0);
      Result[1].Name  := '[Quick add]';
      Result[1].IsDir := False;

      for I := 0 to High(Repos) do
      begin
        if not Repos[I].Enabled then Continue;
        FillChar(E, SizeOf(E), 0);
        E.Name := WideString(Repos[I].DisplayName);
        E.IsDir := True;
        SetLength(Result, Length(Result) + 1);
        Result[High(Result)] := E;
      end;
    end;

    plRepo:
    begin
      Found := FindRepo(Repos, PP.RepoDisplayName, Repo);
      if not Found then Exit;

      Token := GetEffectiveToken(Repo.EncryptedToken);

      if Repo.DefaultBranch <> '' then
      begin
        // Skip branch list: show root contents of the default branch directly
        Contents := nil;
        if not CacheGetContents(Repo.Owner, Repo.RepoName,
                                Repo.DefaultBranch, '', Contents) then
        begin
          if not GHGetContents(Repo.Owner, Repo.RepoName,
                               Repo.DefaultBranch, '', Token, Contents) then Exit;
          CachePutContents(Repo.Owner, Repo.RepoName, Repo.DefaultBranch, '', Contents);
        end;
        SetLength(Result, Length(Contents));
        for I := 0 to High(Contents) do
        begin
          FillChar(E, SizeOf(E), 0);
          E.Name  := WideString(Contents[I].Name);
          E.IsDir := Contents[I].IsDir;
          E.Size  := Contents[I].Size;
          Result[I] := E;
        end;
        Exit;
      end;

      // No DefaultBranch: show branch list
      Branches := nil;
      if not CacheGetBranches(Repo.Owner, Repo.RepoName, Branches) then
      begin
        if not GHGetBranches(Repo.Owner, Repo.RepoName, Token, Branches) then Exit;
        CachePutBranches(Repo.Owner, Repo.RepoName, Branches);
      end;
      SetLength(Result, Length(Branches));
      for I := 0 to High(Branches) do
      begin
        FillChar(E, SizeOf(E), 0);
        E.Name  := WideString(Branches[I].Name);
        E.IsDir := True;
        Result[I] := E;
      end;
    end;

    plBranch, plTree:
    begin
      Found := FindRepo(Repos, PP.RepoDisplayName, Repo);
      if not Found then Exit;

      Token  := GetEffectiveToken(Repo.EncryptedToken);
      Branch := EffectiveBranch(PP, Repo);
      Path   := EffectivePath(PP, Repo);

      LogMsg('[VFS] BuildEntries: branch=' + Branch + ' path=' + Path);

      Contents := nil;
      if not CacheGetContents(Repo.Owner, Repo.RepoName, Branch, Path, Contents) then
      begin
        if not GHGetContents(Repo.Owner, Repo.RepoName,
                             Branch, Path, Token, Contents) then Exit;
        CachePutContents(Repo.Owner, Repo.RepoName, Branch, Path, Contents);
      end;

      SetLength(Result, Length(Contents));
      for I := 0 to High(Contents) do
      begin
        CE := Contents[I];
        FillChar(E, SizeOf(E), 0);
        E.Name  := WideString(CE.Name);
        E.IsDir := CE.IsDir;
        E.Size  := CE.Size;
        Result[I] := E;
      end;
    end;
  end;
end;

// ---------------------------------------------------------------------------
//  GetFile - download from GitHub
// ---------------------------------------------------------------------------
function GetFile(const RemoteName, LocalName: WideString;
                 CopyFlags: Integer;
                 PluginNr: Integer;
                 ProgressCb: TProgressProc): Integer;
var
  PP    : TParsedPath;
  Repos : TRepoConfigArray;
  {%H-}Repo  : TRepoConfig;{%H+}
  Token  : string;
  Branch : string;
  Path   : string;
  RN, LN : AnsiString;
begin
  Result := FS_FILE_NOTSUPPORTED;

  if (CopyFlags and FS_COPYFLAGS_OVERWRITE) = 0 then
    if FileExists(string(LocalName)) then
    begin
      Result := FS_FILE_EXISTS;
      Exit;
    end;

  PP    := ParsePath(RemoteName);
  Repos := LoadRepos;

  if not FindRepo(Repos, PP.RepoDisplayName, Repo) then
  begin
    Result := FS_FILE_NOTFOUND;
    Exit;
  end;

  // With DefaultBranch: plBranch = file/dir directly in repo root, plTree = deeper
  // Without DefaultBranch: only plTree = file (plBranch = directory root, not a file)
  if not IsFileLevel(PP, Repo) then Exit;

  Token  := GetEffectiveToken(Repo.EncryptedToken);
  Branch := EffectiveBranch(PP, Repo);
  Path   := EffectivePath(PP, Repo);

  LogMsg('[VFS] GetFile: branch=' + Branch + ' path=' + Path);

  RN := AnsiString(RemoteName);
  LN := AnsiString(LocalName);

  if Assigned(ProgressCb) then
    ProgressCb(PluginNr, PAnsiChar(RN), PAnsiChar(LN), 0);

  if GHDownloadFile(Repo.Owner, Repo.RepoName,
                    Branch, Path, Token, LocalName,
                    PluginNr, ProgressCb, PAnsiChar(RN), PAnsiChar(LN)) then
    Result := FS_FILE_OK
  else
    Result := FS_FILE_READERROR;
end;

end.
