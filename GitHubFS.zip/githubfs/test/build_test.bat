@echo off
:: Build minimal test plugin
:: Outputs: testfs.wfx64

echo Building testfs.wfx64 (minimal test plugin) ...
fpc -Twin64 -Px86_64 -O1 -WD -otestfs.wfx64 testfs.lpr

if errorlevel 1 (
  echo.
  echo *** BUILD FAILED ***
  exit /b 1
) else (
  echo.
  echo Build successful: testfs.wfx64
  echo.
  echo To install in Total Commander:
  echo   1. Configuration -^> Options -^> Plugins -^> WFX Plugins -^> Add
  echo   2. Browse to testfs.wfx64
  echo   3. After install, click "Network Neighborhood" button in TC
  echo   4. You should see "TestFS" - enter it
  echo   5. You should see one file: Hello.txt
  echo.
  echo If TestFS does NOT appear, the build environment has an issue.
  echo If TestFS appears, the GitHubFS code itself has a bug.
)
