{$mode delphi}{$H+}
{
  testfs.lpr  -  MINIMAL Total Commander WFX 64-bit Test Plugin

  Purpose: Verify that the build environment produces a valid .wfx64 file
  that TC actually loads. If THIS plugin loads, the issue is in our main
  plugin code. If even THIS doesn't load, the build setup is wrong.

  Build:
    fpc -Twin64 -Px86_64 -O1 -WD -otestfs.wfx64 testfs.lpr

  Install in TC:
    Configuration -> Options -> Plugins -> WFX Plugins -> Add -> testfs.wfx64

  Expected behavior:
    - Plugin appears as "TestFS" in Network Neighborhood
    - Entering it shows ONE file: "Hello.txt"
}
library testfs;

uses
  SysUtils, Windows;

// ---------------------------------------------------------------------------
//  TC SDK callback types (minimal)
// ---------------------------------------------------------------------------
type
  TProgressProc = function(PluginNr: Integer; SourceName, TargetName: PAnsiChar;
                           PercentDone: Integer): Integer; stdcall;
  TLogProc      = procedure(PluginNr, MsgType: Integer; LogString: PAnsiChar); stdcall;
  TRequestProc  = function(PluginNr, RequestType: Integer; CustomTitle, CustomText,
                           ReturnedText: PAnsiChar; MaxLen: Integer): BOOL; stdcall;

  TProgressProcW = function(PluginNr: Integer; SourceName, TargetName: PWideChar;
                            PercentDone: Integer): Integer; stdcall;
  TLogProcW      = procedure(PluginNr, MsgType: Integer; LogString: PWideChar); stdcall;
  TRequestProcW  = function(PluginNr, RequestType: Integer; CustomTitle, CustomText,
                            ReturnedText: PWideChar; MaxLen: Integer): BOOL; stdcall;

var
  GPluginNr : Integer = 0;
  GHandled  : Boolean = False;  // simple iterator state

// ===========================================================================
//  ANSI Mandatory Exports
// ===========================================================================

function FsInit(PluginNr: Integer;
                pProgressProc: TProgressProc;
                pLogProc: TLogProc;
                pRequestProc: TRequestProc): Integer; stdcall;
begin
  GPluginNr := PluginNr;
  Result := 0;
end;

function FsFindFirst(Path: PAnsiChar;
                     var FindData: TWin32FindDataA): THandle; stdcall;
var
  Name : AnsiString;
begin
  // Return a single dummy file "Hello.txt"
  FillChar(FindData, SizeOf(FindData), 0);
  FindData.dwFileAttributes := FILE_ATTRIBUTE_NORMAL;
  FindData.nFileSizeLow := 11;
  Name := 'Hello.txt';
  Move(Name[1], FindData.cFileName[0], Length(Name));
  FindData.cFileName[Length(Name)] := #0;
  GHandled := False;
  Result := 1;  // any non-INVALID_HANDLE_VALUE (-1) is OK
end;

function FsFindNext(Hdl: THandle;
                    var FindData: TWin32FindDataA): BOOL; stdcall;
begin
  Result := False;  // no more entries
end;

function FsFindClose(Hdl: THandle): Integer; stdcall;
begin
  Result := 0;
end;

// ===========================================================================
//  Unicode Exports (preferred by TC 64-bit)
// ===========================================================================

function FsInitW(PluginNr: Integer;
                 pProgressProcW: TProgressProcW;
                 pLogProcW: TLogProcW;
                 pRequestProcW: TRequestProcW): Integer; stdcall;
begin
  GPluginNr := PluginNr;
  Result := 0;
end;

function FsFindFirstW(Path: PWideChar;
                      var FindData: TWin32FindDataW): THandle; stdcall;
var
  Name : WideString;
begin
  FillChar(FindData, SizeOf(FindData), 0);
  FindData.dwFileAttributes := FILE_ATTRIBUTE_NORMAL;
  FindData.nFileSizeLow := 11;
  Name := 'Hello.txt';
  Move(Name[1], FindData.cFileName[0], Length(Name) * SizeOf(WideChar));
  FindData.cFileName[Length(Name)] := WideChar(0);
  Result := 1;
end;

function FsFindNextW(Hdl: THandle;
                     var FindData: TWin32FindDataW): BOOL; stdcall;
begin
  Result := False;
end;

// ===========================================================================
//  Plugin name shown in Network Neighborhood
// ===========================================================================

procedure FsGetDefRootName(DefRootName: PAnsiChar; MaxLen: Integer); stdcall;
const
  RootName: AnsiString = 'TestFS';
var
  Len: Integer;
begin
  Len := Length(RootName);
  if Len >= MaxLen then Len := MaxLen - 1;
  Move(RootName[1], DefRootName^, Len);
  PAnsiChar(DefRootName)[Len] := #0;
end;

exports
  // Mandatory ANSI
  FsInit,
  FsFindFirst,
  FsFindNext,
  FsFindClose,
  // Unicode
  FsInitW,
  FsFindFirstW,
  FsFindNextW,
  // Optional but very useful
  FsGetDefRootName;

begin
end.
