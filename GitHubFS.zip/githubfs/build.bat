@echo off
:: ============================================================
::  build.bat – Build GitHubFS.wfx64 with Free Pascal
::
::  Requirements:
::    Free Pascal 3.2+ (fpc.exe) on PATH
::    Target: x86_64-win64
::
::  Usage:
::    build.bat          – normal release build
::    build.bat debug    – debug build (no strip, debug info)
:: ============================================================

setlocal

set OUT=githubfs.wfx64
set SRC=githubfs.lpr
set UNITDIR=src
set OBJDIR=lib\x86_64-win64

if not exist "%OBJDIR%" mkdir "%OBJDIR%"

if /I "%1"=="debug" goto :debug

:: ---- Release build ----
echo Building %OUT% (release x86_64-win64) ...
echo Output target: %CD%\%OUT%
fpc ^
  -Twin64 ^
  -Px86_64 ^
  -O2 ^
  -WD ^
  -Xs ^
  -Mdelphi ^
  -Fu%UNITDIR% ^
  -FU%OBJDIR% ^
  -o%OUT% ^
  %SRC%
goto :done

:debug
:: ---- Debug build ----
echo Building %OUT% (debug x86_64-win64) ...
fpc ^
  -Twin64 ^
  -Px86_64 ^
  -O0 ^
  -WD ^
  -g ^
  -Mdelphi ^
  -Fu%UNITDIR% ^
  -FU%OBJDIR% ^
  -o%OUT% ^
  %SRC%

:done
if errorlevel 1 (
  echo.
  echo *** BUILD FAILED ***
  exit /b 1
) else (
  echo.
  echo Build successful: %OUT%
)
endlocal
