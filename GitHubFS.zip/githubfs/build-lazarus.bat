@echo off
REM ============================================================
REM  GitHubFS - Build Script (Lazarus / FreePascal)
REM
REM  Requirements:
REM   - Lazarus >= 2.2 with lazbuild.exe in PATH
REM
REM  Usage:
REM    build-lazarus.bat          -> builds 64-bit (githubfs.wfx64)
REM    build-lazarus.bat 32       -> builds 32-bit (githubfs.wfx)
REM    build-lazarus.bat both     -> builds both
REM ============================================================

setlocal

where lazbuild.exe >nul 2>&1 || (
    echo ERROR: lazbuild.exe not in PATH.
    echo Install Lazarus and add its installation directory to PATH.
    exit /b 1
)

set ARCH=%1
if "%ARCH%"=="" set ARCH=64

if /i "%ARCH%"=="both" (
    call :build64
    if errorlevel 1 goto :error
    call :build32
    if errorlevel 1 goto :error
    goto :done
)

if /i "%ARCH%"=="32" call :build32
if /i "%ARCH%"=="64" call :build64
if errorlevel 1 goto :error
goto :done

:build64
echo === Cleaning 64-bit cache ===
if exist lib-x64 rmdir /s /q lib-x64
echo === Building 64-bit (githubfs.wfx64) ===
lazbuild.exe --build-mode=Release64 --cpu=x86_64 --os=win64 githubfs.lpi
exit /b %ERRORLEVEL%

:build32
echo === Cleaning 32-bit cache ===
if exist lib-i386 rmdir /s /q lib-i386
echo === Building 32-bit (githubfs.wfx) ===
lazbuild.exe --build-mode=Release32 --cpu=i386 --os=win32 githubfs.lpi
exit /b %ERRORLEVEL%

:error
echo.
echo *** Build failed ***
exit /b 1

:done
echo.
echo *** Build successful ***
dir githubfs.wfx* 2>nul
endlocal
