library githubfs;

{ ========================================================================
  GitHubFS - Total Commander Filesystem Plugin (WFX)
  Browse GitHub repositories as virtual filesystem in TC.

  Build:
    Lazarus/FreePascal:
      - 32-bit: Output -> githubfs.wfx
      - 64-bit: Output -> githubfs.wfx64
    Use 'build-lazarus.bat 64' or open githubfs.lpi in Lazarus IDE.

  Layout follows the proven tcchibiofs WFX plugin pattern:
    - All Fs functions implemented in uWfxMain
    - This file only declares uses + exports
    - The CALLING STDCALL directive below makes stdcall the default
  ======================================================================== }

{$IFDEF FPC}
  {$MODE Delphi}
  {$CALLING STDCALL}
{$ENDIF}

uses
  Windows,
  SysUtils,
  Classes,
  fsplugin        in 'src\fsplugin.pas',
  GitHubTypes     in 'src\GitHubTypes.pas',
  Logger          in 'src\Logger.pas',
  GitHubAPI       in 'src\GitHubAPI.pas',
  GitHubCache     in 'src\GitHubCache.pas',
  PluginConfig    in 'src\PluginConfig.pas',
  VirtualFS       in 'src\VirtualFS.pas',
  ConfigDlg       in 'src\ConfigDlg.pas',
  uWfxMain        in 'src\uWfxMain.pas';

exports
  { Mandatory }
  uWfxMain.FsInit                name 'FsInit',
  uWfxMain.FsFindFirst           name 'FsFindFirst',
  uWfxMain.FsFindNext            name 'FsFindNext',
  uWfxMain.FsFindClose           name 'FsFindClose',

  { Optional, implemented }
  uWfxMain.FsGetDefRootName      name 'FsGetDefRootName',
  uWfxMain.FsSetDefaultParams    name 'FsSetDefaultParams',
  uWfxMain.FsLinksToLocalFiles   name 'FsLinksToLocalFiles',
  uWfxMain.FsExecuteFile         name 'FsExecuteFile',
  uWfxMain.FsGetFile             name 'FsGetFile';

begin
end.
