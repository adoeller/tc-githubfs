@echo off
:: rename_output.bat - Run AFTER Lazarus build to fix the output filename
:: Lazarus appends .dll even when ApplyConventions=False in some versions

if exist "githubfs.wfx64.dll" (
  if exist "githubfs.wfx64" del "githubfs.wfx64"
  ren "githubfs.wfx64.dll" "githubfs.wfx64"
  echo Renamed githubfs.wfx64.dll to githubfs.wfx64
) else if exist "githubfs.dll" (
  if exist "githubfs.wfx64" del "githubfs.wfx64"
  ren "githubfs.dll" "githubfs.wfx64"
  echo Renamed githubfs.dll to githubfs.wfx64
) else (
  echo Nothing to rename - check if build produced any output
)
