# GitHubFS - Total Commander File System Plugin

Browse GitHub repositories as a virtual file system directly in Total Commander's Network Neighborhood.

## Features

- 🌟 **Repository Browsing:** Navigate repositories, branches, and directories as virtual folders
- 🌟 **File Viewing:** Open text files, Markdown, images, and more directly in Total Commander's lister
- 🌟 **File Transfer:** Download files and upload files to configured repository branches
- 🌟 **Write Support:** Upload, delete, copy, move, or rename files in configured repository branches
- 🌟 **Repository Management:** Add, edit, and remove repositories through the settings dialog
- 🌟 **Secure Authentication:** Use GitHub Personal Access Tokens for secure access to your repositories
- 🌟 **Release Management:** View and navigate releases for each repository
- 🌟 **Latest Release Tracking:** Automatically check and highlight the latest release for each repository
- 🌟 **Sortable Repository List:** Sort your repositories by name, owner, latest release, and more

## Setup

1. Install the plugin by copying `GitHubFS.wfx64` to your Total Commander plugins directory
2. Open Total Commander and go to Network Neighborhood
3. Right-click and choose "Add New FTP Connection"
4. Select "GitHubFS" from the list of plugins
5. Click "New" to add your GitHub repositories

### Creating a GitHub Personal Access Token

To access your repositories, you need to create a GitHub Personal Access Token:

1. Log in to your GitHub account
2. Click on your avatar in the top right corner and choose "Settings"
3. In the left sidebar, navigate to "Developer Settings" → "Personal Access Tokens" → "Tokens (classic)"
4. Click "Generate new token" then "Generate new token (classic)"
5. Give your token a name, e.g., "TC WFX Plugin"
6. Grant the necessary permissions:
   - For full access: Check "repo" to grant access to all repository-related endpoints
   - For more secure, granular access: Check "contents" (Read and write) and "metadata" (Read-only)
7. Click "Generate token"
8. Copy the generated token (it will only be shown once) and paste it into the GitHubFS settings dialog

For maximum security, it's recommended to:
- Use granular scopes instead of the broad "repo" scope
- Create separate tokens for public and private repositories
- If you only browse repositories, grant `contents` read access. Uploading or
  renaming files requires `contents` read and write access (or classic `repo`).

## Usage

- Expand the GitHubFS entry in Network Neighborhood to browse your repositories
- Double-click files to open them in the viewer
- Right-click files or directories to download them
- Copy a local file into a repository branch to upload it. Existing files are
  overwritten only after Total Commander confirms the overwrite.
- Copy, move, or rename a file inside the same repository branch with Total
  Commander. A move or rename creates the new file, then removes the old file.
- Delete a repository file with Total Commander's delete command. Deleting a
  repository entry itself still only removes that entry from the plugin configuration.
- Delete a directory recursively with Total Commander's delete command. Its
  contained files are removed together in one Git commit.
  Directory creation, cross-repository moves, and release entries are not writable.
- Uploads are limited to 64 MiB per file to keep both 32-bit and 64-bit plugin
  processes within a predictable memory budget.
- Use Alt+Enter on a repository to edit its settings
- Click the "Check Updates" button in the settings dialog to fetch latest release and latest commit info for all repositories
  - Repositories with an access token are checked for releases via a GraphQL batch request
  - Repositories without a token use the REST release API individually
- Double-click the "Latest Release" or "Latest Commit" cells to jump to the stored release/commit path
- Click column headers in the settings dialog to sort your repositories
- The settings list identifies each provider with GH or SF. The adjacent
  Repository column retains the owner/project and repository information.
- Open `[Check Updates]` in the GitHubFS root to run the same update check
  without opening the configuration dialog
- Both update checks run GitHub requests on a background thread. Their progress
  displays keep processing window messages during slow requests. Configuration
  changes are temporarily disabled until the check finishes.
  During release queries only a status message is shown; the subsequent progress
  bar counts repositories once each while checking their latest commits.

### Custom columns

GitHubFS provides four repository columns for Total Commander:

- `Latest Release` shows the release tag and date stored by the update check
- `Latest Commit` shows the short commit SHA and date stored by the update check
- `Latest Commit Date` shows only the stored commit date
- `Updated` shows `True` when the most recent update check detected a changed release or commit; otherwise it is empty

## Configuration

Missing INI files use the built-in defaults; `githubfs_default.ini` remains a
reference template, not a runtime input. Startup, configuration commands and
the repository editor contain exception boundaries so configuration/parse
errors are reported rather than propagated into Total Commander. Column/icon
requests affected by configuration errors return an error or the standard TC
icon without opening another dialog while the panel is drawing. Invalid
repository counts (outside 0..10000), providers and categories are rejected;
the INI is not automatically reset or repaired. Invalid GitHub URLs stay in the
editor for correction; query strings and fragments are not repository names.
An invalid release-limit translation format falls back to English.
After replacing a plugin that was already loaded, fully restart Total Commander
before testing the new build. This does not establish the cause of a particular
installation-time access violation.


GitHubFS stores its settings in `githubfs.ini` next to the plugin files.

The `[Settings]` section supports:

```ini
[Settings]
AutoUpdateRepos=0
ShowCheckUpdates=1
ShowQuickAdd=1
ShowUpdateBox=0
ShowSources=0
AskCommitMessage=0
DefaultCommitMessage=Update via Total Commander
```

- `AutoUpdateRepos=0` disables automatic update checks when opening the settings dialog (default)
- `AutoUpdateRepos=1` runs the same action as the "Check Updates" button immediately when the settings dialog opens
- `ShowCheckUpdates=1` and `ShowQuickAdd=1` show their filesystem command entries (defaults). Set either to `0` to hide that entry at root and in all virtual categories. Both switches are available in settings; OK saves them, Cancel discards them. The settings dialog's Add and Check Updates buttons remain available.
- `ShowUpdateBox=0` refreshes the panel silently after the root update check (default)
- `ShowUpdateBox=1` additionally shows the update summary dialog
- `ShowSources=0` hides GitHub's automatically generated source archives (default)
- `ShowSources=1` shows `Source code.zip` and `Source code.tar.gz` inside each release
- `AskCommitMessage=0` uses `DefaultCommitMessage` for uploads, deletes, copies, moves, and renames
- `AskCommitMessage=1` asks for the commit message before each write operation and pre-fills the last confirmed text

### Language files

`Language=auto` is the default and follows Total Commander's configured
language. Set `Language` explicitly to a language code to override it. The plugin automatically
loads `language\githubfs.<code>.lng` from the plugin directory. For example,
`Language=fr` loads `githubfs.fr.lng`; `Language=pt-BR` loads
`githubfs.pt-br.lng`. Missing strings fall back to `language\githubfs.en.lng`.

Language files use an INI `[Strings]` section, for example:

```ini
[Strings]
RootName=Depots GitHub
ConfigurationTitle=Systeme de fichiers GitHub - Configuration
```

Each repository section stores the last checked release and commit metadata when known:

The repository editor's `Include pre-releases` checkbox controls `Latest Release`.
The existing INI key retains its inverse meaning: `OnlyReleases=0` (default,
also when the key is absent) includes pre-releases and checks the checkbox.
`OnlyReleases=1` excludes them and unchecks it. Explicitly stored values remain
effective. Drafts are always excluded. The setting
applies per repository to both GraphQL and REST update checks. Run `Check Updates`
after changing it to refresh the stored value and custom column.

`Show only the latest N releases` limits the `[Releases]` folder to the N
most recently published releases. Set `LimitReleasesAmount` under `[Settings]`
to configure the global default (5 if absent or invalid). A positive value in a
repository's INI section overrides the global default. Missing, invalid or
non-positive repository values inherit the global default. To make an existing
repository inherit it, remove its `LimitReleasesAmount` key. Saving settings
preserves this inheritance, including for newly added repositories.
This number is only editable in the INI and is shown in the checkbox label.
This per-repository option is enabled by
default (`LimitReleases=1`, including when the key is absent). Uncheck it
(`LimitReleases=0`) to show the full fetched list. Update checks, cached release
metadata and direct access to older release paths are not limited.

```ini
[Settings]
LimitReleasesAmount=10

[Repo1]
OnlyReleases=0
LimitReleases=1
LimitReleasesAmount=5
LatestRelease=v1.2.3
LatestReleaseDate=2026-06-01T12:34:56Z
LatestReleasePath=\MyRepo\[Releases]\v1.2.3
LatestCommitSHA=0123456789abcdef0123456789abcdef01234567
LatestCommitDate=2026-06-17T08:15:00Z
LatestCommitPath=\MyRepo\main
```

## Preferred Release Downloads

Set **Release files** in the repository editor to a file name or wildcard
pattern, for example `program-*-win64.zip`. The equivalent per-repository INI
key is `PreferredAsset`. An empty value (default) disables the feature.
Patterns support `*` and `?` and are matched without case sensitivity.

All matching assets from the latest eligible release appear directly in the
repository folder with their real file names, sizes and release date. The
**Latest Release** custom column shows their bound release version and date,
both directly in the repository and inside `[Latest Download]`. It does not
use a possibly newer value from a subsequent update check. `[Releases]` has
a system archive icon.
The repository's **Include pre-releases** setting is respected; drafts are excluded.
The release display limit does not affect this selection. No older release is
substituted if the latest release has no matching assets.

- **F5:** download the selected file; multiple matches can be selected together.
- **F3:** download for viewing in Total Commander's Lister (format permitting).
- **Enter:** navigate to the actual release folder.
- **[Latest Download]:** show all matches, including files whose names collide
  with existing repository files or branches. With no matches, this folder
  explains the empty result. API failures are reported separately.

Refresh the repository with **Ctrl+R** to resolve the current release again.
Opening the repository after **Check Updates** also resolves it again. A download
uses the asset URL of the displayed release, not a newly resolved "latest" URL.
These virtual entries are read-only. Existing branch files remain writable.

```ini
[Repo1]
PreferredAsset=program-*-win64.zip
```

## Repository Opening Directory

The repository editor's **Open path (relative)** selects an optional directory
whose contents are mounted directly at the repository's visible root. The repo
stays a normal directory, not a shortcut, and the configured suffix is not added
to TC's visible path. For example, `OpenPath=[Releases]` makes `repo\` show release
versions and `repo\v2\` show that release's files. The label and input share an
explanatory localized tooltip. `OpenPath=` remains empty by default, retaining
the complete original root. This replaces the earlier shortcut behavior for
existing nonempty OpenPath values. Examples:

- `[Releases]` for GitHub releases.
- `release` for SourceForge Files, or `[Files]\release` for SourceForge Both.
- `src` with a configured default branch, or `main\src` with a branch list.
- `[Code]\src` for SourceForge Both with a configured default branch.

Use the actual directory names shown by the plugin. The path is relative to
the repository, not its category or a local drive. `/` is accepted as a
separator. Parent traversal (`..`), URLs, UNC/drive prefixes and wildcards are
rejected. Configuration validation is local; it does not check remote existence.

Mounted roots include **[Repository]**, which opens the complete original repo.
Up from it returns to the mounted root; Up from that root returns to the repo
overview or its category. A real entry called `[Repository]` at the mounted root
is shown as `[[Repository]`; additional leading brackets are escaped likewise,
so no content is hidden by the portal. Only this reserved-name family is changed.

Listings, file downloads, archive previews and GitHub file operations use the
underlying canonical path. Releases/assets and SourceForge stay read-only; code
mounts retain the normal token permissions. Removing or moving a repository
entry is still a local configuration operation, never deletion/copy of its remote
contents. Category moves keep the relative mount. Release/commit navigation and
preferred-download links are translated to visible paths, using [Repository]
when the destination is outside the mounted subtree. Stored metadata paths stay
canonical. Invalid manual mount paths fail closed rather than exposing a writable
fallback root. Saving a changed repo requests a panel reread; unchanged OK and
Cancel do not. Update checks retain their existing semantics.

## Virtual Categories

F7 in the root or a category creates a local virtual category, not a remote
folder or repository. Categories can have multiple levels, e.g. `Tools/Editors`.
The existing **Quick Add** action remains available to add repositories.
The overview commands use the repository icon as their common background,
with separate update/info, configuration/gear and Quick Add/plus overlays.
The same composed icons are used at root and inside categories.

The repository editor has an editable **Category** combo: select an existing
category or enter a nested path; leave it blank to keep the repository at
root. A new assignment is saved only when the repository dialog is confirmed,
so cancelling it does not create a category. Repository display names are not
changed by category assignment. Before accepting the edit, the prospective
repository layout is checked for category/repository path collisions, including
other unsaved changes in the configuration window. Repository display names
remain globally unique; categories do not create separate naming scopes.

Drag-and-drop or F6 can move a repository between local categories or back to
root. For these virtual repository entries, even TC's default copy-style drop
and F5 only reassign the existing entry; they do not duplicate it or transfer
repository contents. Actual files inside repositories retain their normal
copy/move behavior. Only the local configuration changes, not Git contents or
commit history. Saved Latest Release/Latest Commit targets
are rebased to the new virtual location. Deleting a category also removes its
nested category folders. A tree without repository entries needs no additional
plugin confirmation (TC may still show its normal delete confirmation).
If the tree contains repository entries, the plugin warns with their count and
asks Yes/No/Cancel, with **No** selected by default. Only **Yes** removes those
entries from the local configuration together with the category tree; remote
GitHub/SourceForge repositories and their contents are never deleted. **No** or
**Cancel** leaves the category and its entries unchanged. The local change is
atomic; unrelated repository settings and unknown INI keys are preserved when
remaining entries are reindexed. Paths are normalized with `/` in configuration.
Repositories inside a category retain the same configuration, navigation,
downloads, updates and custom-column behavior as repositories at root.
Removing a repository entry inside a category removes only its local
configuration, just as at root; it does not delete the remote repository.
Nested assignments work for new and existing entries. Category trees can also
be moved locally by Drag-and-drop or F6, without copying repository contents.
Configuration is available only at root; categories offer Quick Add and Check
Updates unless disabled by the global visibility switches. Alt+Enter on a
repository still edits that repository. Hiding a command changes only its
listing, not repository data, update checks or the ability to add repos in settings.

Ctrl+R rereads the current directory; it is not a release/commit update check.
Category columns read the latest saved metadata. **[Check Updates]** in a category
checks only repositories assigned to that category or its nested subcategories.
It does not query sibling categories or root-level repositories, clear their
caches, or reset their **Updated** flags. Empty categories make no requests.
The root command and the configuration dialog still check all configured
repositories. Progress and result counts refer only to the current check's scope.
SourceForge Files and GitHub release listings request
fresh data during rereads; ordinary GitHub content listings can still use the
existing content cache.

```ini
[Categories]
Count=2
Path1=Tools
Path2=Tools/Editors

[Repo1]
Category=Tools/Editors
```

The default is `[Categories] Count=0` and an empty repository `Category`.
Categories referenced by repositories are included even without a separate
explicit `PathN` entry. This organizes both GitHub and SourceForge repositories
without changing their provider, configured branch, or remote URLs.

### Check Updates Hotkey

Assign a TC user command to a key under Configuration / Options / Misc. /
Redefine hotkeys. In the command browser choose usercmd.ini and create the
commands below (or add them manually to your own usercmd.ini). Replace
`GitHub Repositories` if your plugin registration uses another name.

```ini
[em_updates_root]
cmd=cd "\\\GitHub Repositories\"

[em_updates_mask]
cmd=SELECTFILES "[Check Updates]"

[em_select_updates]
cmd=em_updates_root,cm_ClearAll,em_updates_mask,cm_GoToFirstEntry,cm_GoToNextSelected,cm_FocusSrc

[em_check_updates]
cmd=em_select_updates,cm_Return
```

Assign `em_check_updates` to the desired key and confirm the assignment with
the checkmark. This switches the active panel to the plugin root and clears
its selection before executing the action; it does not restore the previous
directory. Tested in isolated TC64 11.58.1, including a plugin name containing
spaces. The test used zero repositories and the update result box to prove
execution without network access. The plugin does not modify TC hotkeys or
install these commands automatically. A direct `cd` to the virtual action file
did not work in that host; selecting the quoted file mask explicitly did.
This selection-based command chain requires `ShowCheckUpdates=1`; do not use
it while the filesystem action is hidden. In the plugin settings dialog, F2
already runs Check Updates. TC's normal Ctrl+R (`cm_RereadSource`) only rereads
the current directory. Plugin settings do not assign or change TC hotkeys.

## Repository View

Configuration saves only values that actually changed. An unchanged OK, or a
checkbox toggled back to its original state, does not rewrite the INI or clear
content caches. Changed global options are written together; repository records
are saved only when their data/order changed, with one buffered repository-list
write instead of rewriting the complete INI for every key. An unchanged global
token is not encrypted again. If both settings and repositories changed, each
group is saved once. Unrelated INI sections and inherited release limits remain.
Only changes affecting the panel request a reread of the owning TC window;
commit-message preferences alone do not. Repository edits invalidate affected
repository caches, while a changed global token invalidates all access caches.
Check Updates and the list's Enabled switches retain their existing immediate
saving behavior; closing the dialog refreshes their results without saving twice.

In Configuration, **Repository overview** selects **Plugin columns** (default),
**Only file names**, or **All file details**. **Inside repositories** offers
**Same as overview** (default), **Only file names**, and **All file details**.
These select Total Commander's standard brief/full views or the plugin's own
columns, without simulated keyboard events. Returning to the repository overview
restores its configured view, including when it differs from the inside view.

Global INI keys in `[Settings]`:

- `OverviewView=0`: `0` = plugin columns, `1` = file names, `2` = file details.
- `RepositoryView=0`: `0` = same as overview, `1` = file names, `2` = file details.

Invalid values use `0`.
`githubfs_default.ini` is the reference template, not a runtime INI.

For new GitHub entries, the suggested display name defaults to **owner/repository**
(the original naming style). Enable **Use compact names for new GitHub repos**
in Configuration, or set `[Settings] CompactGitHubNames=1`, to use **repository - branch**
instead; an empty branch omits the suffix. The default is `CompactGitHubNames=0`.
This applies to Add and Quick Add. Automatically filled names follow owner,
repository and branch edits until the name is edited manually. Existing and
custom names are never renamed when this option changes. SourceForge naming is
unchanged. The option alone does not clear caches or refresh the panel.

The actual destination is captured from `FsFindFirst`, rather than assuming
that the LIST END notification contains the new directory. A short deferred
job waits for TC's path control to reflect this destination, then uses fixed
left/right panel commands. New listings invalidate obsolete jobs. It checks
the visible path (including TC's `*.*` mask) and the plugin namespace
registered in the read-only `COMMANDER_INI` configuration, and skips other
plugins, local paths, mismatching/background paths and recursive callbacks.
The existing TC configuration is never edited. If the host cannot supply
panel/path information or the namespace cannot be verified, no switch is sent.
Reliable current-view queries require TC 11.57 or later.
The deferred job holds a temporary DLL reference until its code has finished;
unloading never waits for it under the loader lock.

For a file-names or file-details overview, the SDK callback no longer requests
automatic plugin columns first. Existing TC column definitions remain untouched.
After LIST END, a short-lived paint guard keeps TC's intermediate view changes
out of the list and column header until the selected destination view is ready.
The rest of TC continues painting; no whole-window redraw lock is used. This
starts after remote listing, not during network requests. The existing short
deferred synchronization is retained because TC can restore its own view after
LIST END. Merely removing that delay was insufficient.

UI-thread subclasses used by this guard are removed on completion, cancellation,
missing-destination timeout and control destruction. The worker retains its DLL
reference until UI-thread cleanup really finishes, also after a host FreeLibrary;
no callback removal or blocking thread wait occurs in DLL finalization.
A system-owned message-only window fences the final UI callback return before
the worker releases its DLL reference, including when TC's root is destroyed.
The protected rectangle follows replacement list/header controls created during
TC's view change. Native redraw and input messages are forwarded unchanged;
only painting inside the list/header area is held. TC's reported destination
view must match before that area is released: acknowledging a view command alone
does not mean that TC has completed its asynchronously queued layout changes.
The [paint regression test](test/view_paint/README.md) checks completed list/header
paint events during navigation, not only the final view number. It rejects the
old build under the same forced-redraw stress and accepts the corrected build.

Protocol references: TC's installed `TOTALCMD.INC` and `HISTORY.TXT`,
[WM_USER queries](https://www.ghisler.ch/wiki/index.php?title=WM_USER),
[view-query addition](https://www.ghisler.ch/wiki/index.php?title=List_of_changes_%28version_11.56_-_11.57%29).
Native protocol regression test: `test/panel_view_test.lpr` (build against `src`
for Win32 and Win64). This test does not replace a real-TC acceptance check.
The isolated real-TC64 test `test/tc_view_smoke.lpr` verifies both standard
views and the actual restored headers. TC reserves 100 column indices per
registered WFX, in `FileSystemPlugins` order: index `101` refers to the FIRST
registered plugin, not necessarily GitHubFS. The namespace's own block is
resolved from the read-only registration list; global and foreign-plugin
column sets are never remembered as GitHubFS repository views. An existing
selection within the GitHubFS block is preserved, otherwise its first set is
used. The acceptance test includes three registered plugins and verifies that
the restored columns are `Latest Release`, `Latest Commit`, `Latest Commit
Date`, and `Updated`, not another plugin's owner/group/attributes/info fields.
Fresh views also include size/date. The SDK default uses literal `\n` field
and header separators and comma-separated widths including name/extension,
as required by [FsContentGetDefaultView](https://ghisler.github.io/WFX-SDK/fscontentgetdefaultview.htm).
Existing TC custom-column definitions are not rewritten.
See [test instructions](test/DLL_UNLOAD_TEST.md). No installed plugin or
production TC configuration is modified by these tests.

## DLL Lifetime Regression Tests

Configuration, repository and commit-message dialogs are modal to their owner,
not globally always-on-top. Other applications can cover Total Commander and
its dialogs; closing a dialog restores its owner's previous enabled state.

Native Win32/Win64 load/open/close/unload/reload tests and failure injection
are described in [test/DLL_UNLOAD_TEST.md](test/DLL_UNLOAD_TEST.md).
The current unload audit and results are recorded in [STATUS.md](STATUS.md).
Tests use isolated copies; do not install test binaries over a live plugin.

## SourceForge Git Repositories

### Code, Files and Both

The three persisted modes are:

- `SourceForgeMode=Code` preserves the existing Git repository view and remains
  the compatible INI default when the key is absent.
- `SourceForgeMode=Files` shows the project's downloadable files and folders
  directly at its root. No Git executable, repository name, branch or REST
  repository discovery is required.
- `SourceForgeMode=Both` exposes separate `[Code]` and `[Files]` folders. A Git
  repository must be configured as well as a valid SourceForge project.

New entries in Add/Quick Add select **Auto (detect once)**. When confirming,
Auto calls discovery once and saves the concrete Code, Files or Both result,
never `Auto` in the INI. Existing entries keep their configured mode. A project
short name can be entered instead of a URL; an explicit `/p/project/repository/`
URL selects that Git candidate. In Auto, repository and branch fields are
disabled: specify them through a URL such as
`https://sourceforge.net/p/project/repository/ci/branch/tree/`, or select Code/Both
to edit those fields directly. Detection failures show an error with technical
details and leave the entry unsaved. Manual Code/Files/Both selection remains
available.

For Files mode, enter a project short name or an HTTPS project/files URL, e.g.
`https://sourceforge.net/projects/gnuplot/files/`. HTTPS download mirror URLs
under `downloads.sourceforge.net/project/gnuplot/` or
`<mirror>.dl.sourceforge.net/project/gnuplot/` are also accepted. Folder URLs
retain their subdirectory instead of silently selecting the entire project.
Credentials, foreign hosts, non-HTTPS URLs, nonstandard ports and unsafe path
segments are rejected.

For example, `https://sourceforge.net/projects/nikkhokkho/files/FileOptimizer/`
fills **SF Files root** with `FileOptimizer` and Auto selects **Files**, without
Git discovery. The entry shows FileOptimizer's versions/files, not sibling
folders such as Zerofill. Its default display name is `FileOptimizer`; custom
and existing names remain unchanged. The root can also be edited manually.

The per-repository key `SourceForgeFilesPath` defaults to empty, preserving the
legacy whole-project Files view. A nonempty value bounds listings, downloads,
directory metadata and update fingerprints to that subtree. In **Both**, it
affects only `[Files]`, not `[Code]`. Latest-N version filtering applies within
the selected folder. **Open path** is relative to this Files root (or to the
normal Code/Files virtual root in Both); `[Repository]` does not bypass the
configured Files boundary. Changing the root in the editor clears the old Files
fingerprint and update marker before the next baseline check. Invalid manually
configured roots fail closed, never falling back to the whole project.

For an existing entry whose URL subfolder was discarded by an older version,
set **SF Files root** to `FileOptimizer`, or paste the full folder URL again.
The old INI contains no original URL from which that path could be recovered.
Leave **Open path** empty unless another start directory within the new root
is wanted. Unscoped entries remain unchanged.

```ini
[Repo1]
Provider=SourceForge
SourceForgeMode=Files
SourceForgeFilesPath=
DisplayName=gnuplot downloads
Owner=gnuplot
Repo=
DefaultBranch=
FilesSnapshot=
Enabled=1
```

For the scoped example, use `Owner=nikkhokkho`,
`SourceForgeFilesPath=FileOptimizer` and `DisplayName=FileOptimizer` instead.

In SourceForge **Files** and the **[Files]** part of **Both**, the repository's
**Show only the latest N version folders** checkbox uses the same `LimitReleases`
and `LimitReleasesAmount` settings, including global inheritance and per-repo
overrides. It selects the newest dated version directories by modification time,
not by lexicographic version name. For example, `cudatext/release` can show only
the latest 10 folders instead of all historical versions.

Recognized names include dotted numeric versions (`1.240.0.6`), explicit `v2`,
`release-1.2`/`release_1.2` and `<project>-1.2`/`<project>_1.2`, with optional
prerelease suffixes. Other structure/platform folders and all files remain.
Version folders with missing/invalid dates are also retained, so the total may
exceed N. Contents below a recognized version are never limited. Disabling the
checkbox restores the full listing; direct paths to older versions, backend
caches, downloads and update fingerprints remain unaffected. This is display
filtering, not reduced network fetching. Git tags in **Code** are unchanged.

Files dates come from the HTML listing. Exact sizes are shown only when numeric
metadata provides them; otherwise size is unknown (`0`), not a confirmed empty
file. Rounded HTML labels such as `4.9 MB` are parsed separately as approximate
metadata only, not promoted to exact listed byte counts or used for transfer
length verification. There are no extra HEAD requests per entry to discover sizes.

`FilesSnapshot` is a saved, bounded fingerprint of the root Files listing
(names and available dates/sizes), not a release or version. The first successful check
establishes a baseline; later changes set `Updated=True`. Checks do not traverse
subfolders, infer a latest version, or apply recursive download patterns in
this phase. Changing the mode clears this snapshot and stale Git metadata.
GitHub behavior is unchanged.

Optional Files backend settings in `[Settings]` (15 keys, with defaults):

```ini
SourceForgeFilesTableID=files_list
SourceForgeFilesRowTag=tr
SourceForgeFilesLinkTag=a
SourceForgeFilesLinkAttribute=href
SourceForgeFilesFolderClass=folder
SourceForgeFilesFileClass=file
SourceForgeFilesIgnoreRowClass=tablesorter-ignoreRow
SourceForgeFilesDateTag=abbr
SourceForgeFilesDateAttribute=title
SourceForgeFilesSizeTag=td
SourceForgeFilesSizeAttribute=headers
SourceForgeFilesSizeHeader=files_size_h
SourceForgeFilesJSONMarker=net.sf.files
SourceForgeFilesTimeoutSeconds=120
SourceForgeFilesMaxDownloadMiB=10240
```

These configure the listing table ID, row/link tags, target link attribute,
folder/file classes, ignored row class, timestamp tag/attribute, approximate
size cell tag/attribute/header value and embedded metadata marker.
They are literal names, not executable scripts or full CSS selectors. The
timeout accepts 10–1800 seconds and the download limit 1–10240 MiB; invalid
values revert to the defaults. Listings are limited to 8 MiB. These Files
settings are independent of the Code-mode parser settings below.

Win32 and Win64 passed backend and integration offline/live tests: all four
configured test projects, root/nested listings, snapshot baseline/change/no-change
and persistence. Both targets also downloaded a 24,747-byte ZIP through the VFS
and verified its signature. Native dialog/panel/unload tests and the five existing
GitHub regression suites passed on both targets. An isolated real TC64 test
confirmed Files navigation, rereading and return to the plugin's root columns;
real TC32 was not available. Tests used private fixtures/configuration and did
not modify installed plugins or productive settings. See the
[backend tests](test/sourceforge_files_backend/README.md),
[integration acceptance logs](test/sourceforge_files_integration/README.md#code-freeze-confirmation)
and [real-TC64 test](test/DLL_UNLOAD_TEST.md#sourceforge-files-control).
Unsupported markup and access challenges are errors, not empty folders or
successful file downloads.

### Code Mode

Choose **SourceForge** in the repository editor. Enter a project URL such as
`https://sourceforge.net/projects/gnuplot` or a repository URL such as
`https://sourceforge.net/p/gnuplot/gnuplot-main/`. Discovery runs when pressing
OK, not while typing. If the project has multiple repositories, use an explicit
repository URL; project and repository can also be entered directly.

```ini
[Repo1]
Provider=SourceForge
DisplayName=gnuplot
Owner=gnuplot
Repo=gnuplot-main
DefaultBranch=master
Enabled=1
```

`Provider` defaults to `GitHub` for existing configurations. For SourceForge,
`Owner` is the plain SourceForge project short name, not a GitHub username.
The internal `sourceforge:` routing prefix is never needed in the INI.

SourceForge support is read-only and requires Git on PATH or an explicitly
configured Git executable, but does not clone,
fetch, check out, or create a local Git object database. Branches, tags and the
current commit ID are obtained with `git ls-remote`; update detection compares
branch commit IDs. A version is a **Git tag**, not a published release. Tags
appear under `[Tags]`, sorted by version name rather than publication date.
Commit details use REST and directories use HTML. Directory dates and sizes are
initially unknown. GitHub tokens, avatars, pre-release filters and release-asset
patterns do not apply and are disabled in the editor.

Single-file remote archive downloads depend on the server's archive support.
The `git://` archive transport is unencrypted; it is not HTTPS. Git archives can
apply `export-ignore`/`export-subst`, so an archive export is not guaranteed to
equal raw Git file contents. No GitHub token is sent to SourceForge.
Requests are bounded to 30 seconds and 64 MiB of output. Unsupported archive
entries, including symlinks and long-path extensions, fail explicitly. Changed
paths are not currently available in the SourceForge commit tooltip.

Optional global settings (shown with their defaults):

```ini
[Settings]
SourceForgeGitExecutable=git.exe
SourceForgeTableClass=
SourceForgeFolderClass=fa-folder
SourceForgeTableTag=table
SourceForgeEntryTag=a
SourceForgeLinkAttribute=href
SourceForgeNameAttribute=title
```

`SourceForgeGitExecutable` accepts an executable name on PATH or a full path
to `git.exe`. `SourceForgeTableClass` optionally restricts the directory parser
to tables with the given HTML class; empty means no table-class restriction.
`SourceForgeFolderClass` identifies folder entries by HTML class.
`SourceForgeTableTag` and `SourceForgeEntryTag` specify the HTML tags for the
directory table and entry links. `SourceForgeLinkAttribute` specifies the
attribute containing the link target; `SourceForgeNameAttribute` specifies
the attribute containing the displayed file name. These settings are literal
tag, class and attribute names, not arbitrary CSS selectors. They allow adapting markup changes
without rebuilding the plugin, but cannot bypass access challenges or handle
every structural website change.

Provider regression and public read-only live tests are documented in
`test/sourceforge_integration/README.md`. Native UI/load/unload coverage is
documented in `test/DLL_UNLOAD_TEST.md`.

## Feedback & Contributions

If you encounter any issues, have suggestions, or want to contribute to the project, please open an issue or submit a pull request on the [GitHubFS GitHub repository](https://github.com/adoeller/GitHubFS).

Enjoy browsing your GitHub repositories in Total Commander with GitHubFS! 🚀
